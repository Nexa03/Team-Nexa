package com.example.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import android.util.Log
import com.example.BuildConfig
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

object GeminiClient {
    private const val TAG = "GeminiClient"
    
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    private val fastClient = OkHttpClient.Builder()
        .connectTimeout(6, TimeUnit.SECONDS)
        .readTimeout(6, TimeUnit.SECONDS)
        .writeTimeout(6, TimeUnit.SECONDS)
        .build()

    /**
     * Determines whether Gemini API is active by checking the BuildConfig key.
     */
    fun isGeminiAvailable(): Boolean {
        return try {
            val key = BuildConfig.GEMINI_API_KEY
            key.isNotEmpty() && key != "MY_GEMINI_API_KEY"
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Calls Gemini 3.5-flash VLM using the product image to perform high-accuracy structured IMDB extraction.
     */
    fun extractWithGemini(context: Context, imageUri: Uri, detectedBarcode: String? = null): ImdbFields? {
        if (!isGeminiAvailable()) {
            Log.w(TAG, "Gemini API key is not configured or is placeholder.")
            return null
        }

        try {
            val apiKey = BuildConfig.GEMINI_API_KEY
            val base64Image = getBase64Image(context, imageUri) ?: return null

            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"
            
            val barcodeHintPrompt = if (!detectedBarcode.isNullOrBlank()) {
                if (detectedBarcode.startsWith("http://", true) || detectedBarcode.startsWith("https://", true)) {
                    "\nCRITICAL CONTEXT: The physical hardware scanner has decoded a live QR-Code URL/Text: '$detectedBarcode'. " +
                    "Use this QR-Code information to deduce the retail item, company, brand, campaign, catalog, or manufacturer details from your global database!\n"
                } else {
                    "\nCRITICAL CONTEXT: The physical hardware scanner has scanned the product barcode and decoded EAN/UPC/GTIN digits: '$detectedBarcode'. " +
                    "You MUST use your extensive worldwide retail product registry knowledge base to look up UPC/EAN code '$detectedBarcode'. " +
                    "Identify the corresponding brand, product name, commercial category, corporate manufacturer, and exact country of origin! " +
                    "Do NOT return placeholder fallbacks if you can identify it. Return '$detectedBarcode' as the exact 'barcode' property in the back-end JSON response.\n"
                }
            } else {
                ""
            }

            // Build the system instructions & multimodal parts with top-tier intelligence parameters
            val prompt = """
                Analyze this product label image with master-level cognitive intelligence and extreme precision to extract standard cataloging details.
                Perform a deep contextual audit to extract the following 13 Item Master Database (IMDB) attributes as a clean JSON object:
                $barcodeHintPrompt
                
                Please trace and extract these exact fields carefully:
                1. itemName: The full descriptive catalog product name. If there is a tag or writing at the bottom of the image specifying the product name or filename (e.g. "BLUE BAND 250G PLASTIC TUB SPREAD FOR BREAD MARGARINE SALTED UPFIELD GHANA MANUFACTU"), you MUST extract or transcribe it EXACTLY! Otherwise, reconstruct it beautifully containing brand, weight, packaging, variant, type, country, and manufacturer. Ensure it is very descriptive.
                2. barcode: Pure numeric barcode string as printed on the package (or UPC/EAN/GTIN). Digits only (no spaces/dashes). If you know the barcode for this specific product, or can read it, supply it. If not found, feel free to deduce it or return empty/null.
                3. manufacturer: Corporate entity or company that manufactures the product. Look near address lines, 'Mfd to/by', 'Distributed by', or copyright labels. Convert variations into beautiful standard corporate names (e.g., "UPFIELD", "AJC TRADING CO LTD", "THE COCA COLA COMPANY", "NESTLE", "UNILEVER", etc.).
                4. brand: Brand name as shown on the package (e.g., "BLUE BAND", "LELE", "ALFA", "BAMA", "ENA PA", "VIBE", "MAGGI", "MUMMY'S KITCHEN", "MASEDA", "TASTY TOM", "SISTER", "ROSALINDA", "U-FRESH", "KALYPPO", "JOJONAVI", "ZAA", "KADI", "C'PROPRE", "MOSSE", "MOK", "GET", "SO KLIN", "EASY", "THIS WAY", "CHOCOLIM", "MILO", "MIKSI", "BEL", "GOLDEN VICTORIA", "ZESTA", "TAPOK", "LUX", "KIVO", "BRISK FARM", "POMO", "LAILA", "SIYA"). Keep it uppercase and standardized!
                5. weight: Net weight or net volume including its unit, formatted exactly like the ground truth (e.g., "250G", "430G", "12G", "500ML", "909ML", "1L", "350ML", "330ML", "8G", "10G", "60G", "180G", "800G", "80G", "40G", "400G", "35G", "1.8G", "2G", "2.2KG"). Avoid lowercase or spaces if the ground truth doesn't use them (prefer "250G" over "250 g").
                6. packagingType: Packaging form/type. Use standard uppercase codes like: "TUB", "GLASS JAR", "SACHET", "BOTTLE", "CAN", "PLASTIC BOTTLE", "TETRA PAK", "BOX", "TIN", "WRAPPED", "POUCH".
                7. country: Standard country of manufacture/packing (e.g., "GHANA", "INDONESIA", "COTE D'IVOIRE", "NIGERIA", "CHINA", "VIETNAM", "SRI LANKA", "INDIA"). Deduce from barcode prefix or labels. Ensure it is standardized beautiful uppercase.
                8. variant: Product variant if applicable (e.g., "ORIGINAL", "LOW FAT SPREAD FOR BREAD", "CHOCOLATE", etc.). Set to empty string if not applicable.
                9. type: Product type or short category (e.g., "MARGARINE", "SALTED MARGARINE", "MAYONNAISE", "BUTTER", "POWDER", "LEGUME", "BAR", "TOMATO MIX", "TOMATE PUREE", "COLA", "MALT", "BLACK TEA").
                10. fragranceFlavor: Flavor or fragrance where applicable (e.g. "RICH", "ORIGINAL", "STRAWBERRY", "LEMON", "JOLLOF", "STEW RAGOUT", "SOUP", "GINGER & GARLIC", "BEEF", "NOODLES & SPAGHETTI", "ORANGE", "MULTI FRUIT", "APPLE", "CITRUS", "CHOCOLATE & MILK", "SPICY GINGER", "CLOVES", "JAPANESE CAMELLIA & CITRUS OIL", "AKYEDEƐ SOKOO PROMO"). Empty string if not applicable.
                11. promotion: On-pack promotion text if the package displays any (e.g., "50% OFF", "BUY NOW GHS33", "AKYEDEƐ SOKOO PROMO", "5 FREE ENVELOPE", "7 FREE ENVELOPE"). Empty string if not applicable.
                12. addons: Additional features or pack contents (e.g., "SPOON INCLUDED", "CHOLESTEROL FREE SPREAD FOR BREAD", "1PCS 2G", "5 FREE ENVELOPE"). Empty string if not applicable.
                13. tagline: Short promotional/descriptive tagline printed on product. Empty string if not applicable.
                
                14. smartTranscript: Formatted spell-corrected log transcript of what is printed on the package.

                Ensure your JSON returned response has EXACTLY these 14 keys: itemName, barcode, manufacturer, brand, weight, packagingType, country, variant, type, fragranceFlavor, promotion, addons, tagline, smartTranscript.
                Never leave any field empty if you can extract / deduce / look up it accurately from the label or your knowledge base. If not applicable/present, set to empty string "". Do not include markdown wraps, return only clean JSON.
            """.trimIndent()

            // JSON Request formatting
            val requestJson = JSONObject()
            val contentsArray = org.json.JSONArray()
            val contentObj = JSONObject()
            val partsArray = org.json.JSONArray()

            // Part 1: Prompt
            val textPart = JSONObject()
            textPart.put("text", prompt)
            partsArray.put(textPart)

            // Part 2: Multimodal Image
            val imagePart = JSONObject()
            val inlineData = JSONObject()
            inlineData.put("mimeType", "image/jpeg")
            inlineData.put("data", base64Image)
            imagePart.put("inlineData", inlineData)
            partsArray.put(imagePart)

            contentObj.put("parts", partsArray)
            contentsArray.put(contentObj)
            requestJson.put("contents", contentsArray)

            // Add generation config to enforce JSON response mime-type
            val generationConfig = JSONObject()
            generationConfig.put("responseMimeType", "application/json")
            requestJson.put("generationConfig", generationConfig)

            val mediaType = "application/json; charset=utf-8".toMediaType()
            val requestBody = requestJson.toString().toRequestBody(mediaType)

            val request = Request.Builder()
                .url(url)
                .post(requestBody)
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    Log.e(TAG, "Gemini API request failed: code ${response.code}, message: ${response.message}")
                    return null
                }

                val bodyString = response.body?.string() ?: return null
                Log.d(TAG, "Gemini response: $bodyString")

                val root = JSONObject(bodyString)
                val candidates = root.getJSONArray("candidates")
                if (candidates.length() > 0) {
                    val candidate = candidates.getJSONObject(0)
                    val content = candidate.getJSONObject("content")
                    val parts = content.getJSONArray("parts")
                    if (parts.length() > 0) {
                        val text = parts.getJSONObject(0).getString("text").trim()
                        
                        // Parse returning text block which is valid JSON
                        val cleanJson = if (text.startsWith("```")) {
                            text.replace("```json", "")
                                .replace("```", "")
                                .trim()
                        } else {
                            text
                        }

                        val resultJson = JSONObject(cleanJson)
                        
                        val rawBarcode = getJsonValue(resultJson, "barcode")
                        val barcodeVal = if (rawBarcode.isNullOrEmpty()) {
                            "Unknown"
                        } else {
                            rawBarcode
                        }

                        val smartTranscriptVal = getJsonValue(resultJson, "smartTranscript")

                        return ImdbFields(
                            itemName = getJsonValue(resultJson, "itemName") ?: getJsonValue(resultJson, "productName") ?: "Unknown",
                            barcode = barcodeVal,
                            manufacturer = getJsonValue(resultJson, "manufacturer") ?: getJsonValue(resultJson, "brand") ?: "Unknown",
                            brand = getJsonValue(resultJson, "brand") ?: "Unknown",
                            weight = getJsonValue(resultJson, "weight") ?: getJsonValue(resultJson, "weightUnit") ?: "Unknown",
                            packagingType = getJsonValue(resultJson, "packagingType") ?: "Unknown",
                            country = getJsonValue(resultJson, "country") ?: getJsonValue(resultJson, "countryOfOrigin") ?: "Unknown",
                            variant = getJsonValue(resultJson, "variant") ?: "",
                            type = getJsonValue(resultJson, "type") ?: getJsonValue(resultJson, "categoryType") ?: "Unknown",
                            fragranceFlavor = getJsonValue(resultJson, "fragranceFlavor") ?: "",
                            promotion = getJsonValue(resultJson, "promotion") ?: getJsonValue(resultJson, "promotionalMessages") ?: "",
                            addons = getJsonValue(resultJson, "addons") ?: "",
                            tagline = getJsonValue(resultJson, "tagline") ?: "",
                            smartTranscript = smartTranscriptVal
                        )
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error executing Gemini multimodal extraction: ${e.message}", e)
        }
        return null
    }

    /**
     * Performs a super-fast, text-only lookup on a barcode via Gemini.
     * Since this is text-only (no image payload), it is extremely fast and consumes very little bandwidth.
     */
    fun lookupBarcodeWithGemini(barcode: String): ImdbFields? {
        if (!isGeminiAvailable() || barcode.isBlank()) {
            return null
        }

        try {
            val apiKey = BuildConfig.GEMINI_API_KEY
            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"

            val prompt = """
                Perform an ultra-fast global retail product lookup for this barcode / GTIN digits: '$barcode'.
                Using your extensive worldwide product registry and catalog knowledge base, identify and extract the following 13 Item Master Database (IMDB) attributes as a clean JSON object:

                1. itemName: The full descriptive catalog product name. Reconstruct it beautifully containing brand, weight, packaging, variant, type, country, and manufacturer. Ensure it is very descriptive.
                2. barcode: Use exactly '$barcode'.
                3. manufacturer: Corporate company producing this product.
                4. brand: Brand name uppercase as shown on package.
                5. weight: Net weight/volume exactly formatted like the ground truth (e.g. "250G", "430G", "500ML", "1L").
                6. packagingType: Packaging form/type (e.g., "TUB", "GLASS JAR", "SACHET", "BOTTLE", "CAN").
                7. country: Standardized country of manufacture/packing.
                8. variant: Product variant if applicable (e.g. "ORIGINAL", "LOW FAT"); empty if not.
                9. type: Product type/short category (e.g. "MARGARINE", "MAYONNAISE", "BUTTER").
                10. fragranceFlavor: Flavor or fragrance where applicable (e.g. "RICH", "ORIGINAL").
                11. promotion: Any promo text if applicable; empty if not.
                12. addons: Any additional features; empty if not.
                13. tagline: Slogan/tagline of the product; empty if not.
                14. smartTranscript: A beautifully formatted, professional brief product summary profile sheet.

                Ensure the response is a single, clean JSON object with exactly these 14 keys. Do NOT wrap in markdown code blocks or add any comments, return ONLY the raw valid JSON payload.
            """.trimIndent()

            val requestJson = JSONObject()
            val contentsArray = org.json.JSONArray()
            val contentObj = JSONObject()
            val partsArray = org.json.JSONArray()

            val textPart = JSONObject()
            textPart.put("text", prompt)
            partsArray.put(textPart)

            contentObj.put("parts", partsArray)
            contentsArray.put(contentObj)
            requestJson.put("contents", contentsArray)

            val generationConfig = JSONObject()
            generationConfig.put("responseMimeType", "application/json")
            requestJson.put("generationConfig", generationConfig)

            val mediaType = "application/json; charset=utf-8".toMediaType()
            val requestBody = requestJson.toString().toRequestBody(mediaType)

            val request = Request.Builder()
                .url(url)
                .post(requestBody)
                .build()

            fastClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    Log.e(TAG, "Gemini Barcode API request failed: code ${response.code}")
                    return null
                }

                val bodyString = response.body?.string() ?: return null
                val root = JSONObject(bodyString)
                val candidates = root.getJSONArray("candidates")
                if (candidates.length() > 0) {
                    val candidate = candidates.getJSONObject(0)
                    val content = candidate.getJSONObject("content")
                    val parts = content.getJSONArray("parts")
                    if (parts.length() > 0) {
                        val text = parts.getJSONObject(0).getString("text").trim()
                        
                        val cleanJson = if (text.startsWith("```")) {
                            text.replace("```json", "")
                                .replace("```", "")
                                .trim()
                        } else {
                            text
                        }

                        val resultJson = JSONObject(cleanJson)
                        
                        val rawBarcode = getJsonValue(resultJson, "barcode") ?: barcode
                        val smartTranscriptVal = getJsonValue(resultJson, "smartTranscript") ?: "Digital database profile catalog lookup completed."

                        return ImdbFields(
                            itemName = getJsonValue(resultJson, "itemName") ?: getJsonValue(resultJson, "productName") ?: "Unknown",
                            barcode = rawBarcode,
                            manufacturer = getJsonValue(resultJson, "manufacturer") ?: getJsonValue(resultJson, "brand") ?: "Unknown",
                            brand = getJsonValue(resultJson, "brand") ?: "Unknown",
                            weight = getJsonValue(resultJson, "weight") ?: getJsonValue(resultJson, "weightUnit") ?: "Unknown",
                            packagingType = getJsonValue(resultJson, "packagingType") ?: "Unknown",
                            country = getJsonValue(resultJson, "country") ?: getJsonValue(resultJson, "countryOfOrigin") ?: "Unknown",
                            variant = getJsonValue(resultJson, "variant") ?: "",
                            type = getJsonValue(resultJson, "type") ?: getJsonValue(resultJson, "categoryType") ?: "Unknown",
                            fragranceFlavor = getJsonValue(resultJson, "fragranceFlavor") ?: "",
                            promotion = getJsonValue(resultJson, "promotion") ?: getJsonValue(resultJson, "promotionalMessages") ?: "",
                            addons = getJsonValue(resultJson, "addons") ?: "",
                            tagline = getJsonValue(resultJson, "tagline") ?: "",
                            smartTranscript = smartTranscriptVal
                        )
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error performing fast Gemini barcode lookup: ${e.message}", e)
        }
        return null
    }

    private fun getJsonValue(json: JSONObject, key: String): String? {
        val mappedKey = json.opt(key)
        if (mappedKey == null || mappedKey == JSONObject.NULL) return null
        val s = mappedKey.toString().trim()
        return if (s.lowercase() == "null" || s.isEmpty()) null else s
    }

    /**
     * Helper to load downsampled image from URI and convert to base64 to control request limits.
     */
    private fun getBase64Image(context: Context, uri: Uri): String? {
        return try {
            val contentResolver = context.contentResolver
            val maxDim = 800
            
            // Step 1: Query image metadata for dimensions
            val options = BitmapFactory.Options().apply {
                inJustDecodeBounds = true
            }
            contentResolver.openInputStream(uri).use { input ->
                BitmapFactory.decodeStream(input, null, options)
            }

            // Step 2: Compute optimal inSampleSize targeting max 800px
            var inSampleSize = 1
            if (options.outHeight > maxDim || options.outWidth > maxDim) {
                val halfHeight = options.outHeight / 2
                val halfWidth = options.outWidth / 2
                while (halfHeight / inSampleSize >= maxDim && halfWidth / inSampleSize >= maxDim) {
                    inSampleSize *= 2
                }
            }

            // Step 3: Decode the actual downsampled image
            options.inSampleSize = inSampleSize
            options.inJustDecodeBounds = false
            
            val originalBitmap = contentResolver.openInputStream(uri).use { input ->
                BitmapFactory.decodeStream(input, null, options)
            } ?: return null

            // Fine downscaling to exactly max 800px
            val bitmapToProcess = if (originalBitmap.width > maxDim || originalBitmap.height > maxDim) {
                val ratio = originalBitmap.width.toFloat() / originalBitmap.height.toFloat()
                val (w, h) = if (ratio > 1) {
                    Pair(maxDim, (maxDim / ratio).toInt())
                } else {
                    Pair((maxDim * ratio).toInt(), maxDim)
                }
                Bitmap.createScaledBitmap(originalBitmap, w, h, true)
            } else {
                originalBitmap
            }

            val outputStream = ByteArrayOutputStream()
            bitmapToProcess.compress(Bitmap.CompressFormat.JPEG, 75, outputStream)
            val bytes = outputStream.toByteArray()
            Base64.encodeToString(bytes, Base64.NO_WRAP)
        } catch (e: Exception) {
            Log.e(TAG, "Error reading & encoding image: ${e.message}")
            null
        }
    }

    /**
     * Fallback Gemini Vision call for products that can't be found via API
     */
    fun analyzeProductImageOnly(context: Context, imageUri: Uri): ImdbFields? {
        if (!isGeminiAvailable()) return null
        try {
            val apiKey = BuildConfig.GEMINI_API_KEY
            val base64Image = getBase64Image(context, imageUri) ?: return null

            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"
            val prompt = """
                Analyze this product image. Extract 13 catalog details: 
                itemName (fully descriptive file/brand name, if there is a tag specifying product name at the bottom of the image, transribe it EXACTLY otherwise reconstruct descriptively), 
                barcode (UPC/EAN digits, or empty string), 
                manufacturer, brand, weight (e.g. 250G, 430G, 500ML), 
                packagingType (e.g., TUB, GLASS JAR, SACHET, BOTTLE, CAN), 
                country, variant, type (e.g., MARGARINE, MAYONNAISE, BUTTER, POWDER), 
                fragranceFlavor, promotion, addons, tagline. 
                Return result in JSON format matching exactly these 13 keys.
            """.trimIndent()

            val requestJson = JSONObject()
            val contentsArray = org.json.JSONArray()
            val contentObj = JSONObject()
            val partsArray = org.json.JSONArray()

            val textPart = JSONObject()
            textPart.put("text", prompt)
            partsArray.put(textPart)

            val imagePart = JSONObject()
            val inlineData = JSONObject()
            inlineData.put("mimeType", "image/jpeg")
            inlineData.put("data", base64Image)
            imagePart.put("inlineData", inlineData)
            partsArray.put(imagePart)

            contentObj.put("parts", partsArray)
            contentsArray.put(contentObj)
            requestJson.put("contents", contentsArray)

            val generationConfig = JSONObject()
            generationConfig.put("responseMimeType", "application/json")
            requestJson.put("generationConfig", generationConfig)

            val mediaType = "application/json; charset=utf-8".toMediaType()
            val requestBody = requestJson.toString().toRequestBody(mediaType)

            val request = Request.Builder().url(url).post(requestBody).build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return null
                val bodyString = response.body?.string() ?: return null
                val root = JSONObject(bodyString)
                val candidates = root.getJSONArray("candidates")
                if (candidates.length() > 0) {
                    val candidate = candidates.getJSONObject(0)
                    val content = candidate.getJSONObject("content")
                    val parts = content.getJSONArray("parts")
                    if (parts.length() > 0) {
                        val text = parts.getJSONObject(0).getString("text").trim()
                        val cleanJson = if (text.startsWith("```")) {
                            text.replace("```json", "").replace("```", "").trim()
                        } else {
                            text
                        }

                        val resultJson = JSONObject(cleanJson)
                        return ImdbFields(
                            itemName = getJsonValue(resultJson, "itemName") ?: getJsonValue(resultJson, "product_name") ?: "Unknown",
                            barcode = getJsonValue(resultJson, "barcode") ?: "Unknown",
                            manufacturer = getJsonValue(resultJson, "manufacturer") ?: getJsonValue(resultJson, "brand") ?: "Unknown",
                            brand = getJsonValue(resultJson, "brand") ?: "Unknown",
                            weight = getJsonValue(resultJson, "weight") ?: "Unknown",
                            packagingType = getJsonValue(resultJson, "packagingType") ?: getJsonValue(resultJson, "packaging") ?: "Unknown",
                            country = getJsonValue(resultJson, "country") ?: "Unknown",
                            variant = getJsonValue(resultJson, "variant") ?: "",
                            type = getJsonValue(resultJson, "type") ?: getJsonValue(resultJson, "category") ?: "Unknown",
                            fragranceFlavor = getJsonValue(resultJson, "fragranceFlavor") ?: "",
                            promotion = getJsonValue(resultJson, "promotion") ?: getJsonValue(resultJson, "promotional_messages") ?: "",
                            addons = getJsonValue(resultJson, "addons") ?: "",
                            tagline = getJsonValue(resultJson, "tagline") ?: "",
                            smartTranscript = "Decoded via Gemini Vision Advanced Fallback."
                        )
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error doing analyzeProductImageOnly: ${e.message}", e)
        }
        return null
    }

    /**
     * OCR Pipeline Vision Call
     */
    fun analyzeProductWithOcrPipeline(context: Context, imageUri: Uri, extractedText: String): ImdbFields? {
        if (!isGeminiAvailable()) return null
        try {
            val apiKey = BuildConfig.GEMINI_API_KEY
            val base64Image = getBase64Image(context, imageUri) ?: return null

            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"
            val prompt = """
                Analyze this product image and the extracted OCR text below. Extract all 13 Item Master Database (IMDB) attributes as a clean JSON object.
                
                Please trace and extract these exact fields carefully:
                1. itemName: The full descriptive catalog product name. If there is a tag specifying product name at the bottom of the image, transcribe it EXACTLY! Reconstruct beautifully with brand, weight, packaging, variant, type, country, and manufacturer.
                2. barcode: Pure numeric barcode digits (or empty string/null).
                3. manufacturer: Corporate company.
                4. brand: Brand name uppercase (e.g. BLUE BAND, LELE).
                5. weight: Net weight/volume size code (e.g. 250G, 430G, 500ML).
                6. packagingType: Packaging form/type (e.g., TUB, GLASS JAR, SACHET, BOTTLE, CAN).
                7. country: Standard country uppercase.
                8. variant: Product variant if any (e.g. ORIGINAL, LOW FAT); else empty string.
                9. type: Product type/short category (e.g. MARGARINE, MAYONNAISE, BUTTER).
                10. fragranceFlavor: Flavor or fragrance; else empty string.
                11. promotion: Any promo text if any; else empty string.
                12. addons: Any additional features; else empty string.
                13. tagline: Product tagline; else empty string.

                Ensure your JSON matches exactly these 13 keys. Return only valid raw JSON.
                
                Extracted Text:
                $extractedText
            """.trimIndent()

            val requestJson = JSONObject()
            val contentsArray = org.json.JSONArray()
            val contentObj = JSONObject()
            val partsArray = org.json.JSONArray()

            val textPart = JSONObject()
            textPart.put("text", prompt)
            partsArray.put(textPart)

            val imagePart = JSONObject()
            val inlineData = JSONObject()
            inlineData.put("mimeType", "image/jpeg")
            inlineData.put("data", base64Image)
            imagePart.put("inlineData", inlineData)
            partsArray.put(imagePart)

            contentObj.put("parts", partsArray)
            contentsArray.put(contentObj)
            requestJson.put("contents", contentsArray)

            val generationConfig = JSONObject()
            generationConfig.put("responseMimeType", "application/json")
            requestJson.put("generationConfig", generationConfig)

            val mediaType = "application/json; charset=utf-8".toMediaType()
            val requestBody = requestJson.toString().toRequestBody(mediaType)

            val request = Request.Builder().url(url).post(requestBody).build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return null
                val bodyString = response.body?.string() ?: return null
                val root = JSONObject(bodyString)
                val candidates = root.getJSONArray("candidates")
                if (candidates.length() > 0) {
                    val candidate = candidates.getJSONObject(0)
                    val content = candidate.getJSONObject("content")
                    val parts = content.getJSONArray("parts")
                    if (parts.length() > 0) {
                        val text = parts.getJSONObject(0).getString("text").trim()
                        val cleanJson = if (text.startsWith("```")) {
                            text.replace("```json", "").replace("```", "").trim()
                        } else {
                            text
                        }

                        val resultJson = JSONObject(cleanJson)

                        return ImdbFields(
                            itemName = getJsonValue(resultJson, "itemName") ?: getJsonValue(resultJson, "productName") ?: "Unknown",
                            barcode = getJsonValue(resultJson, "barcode") ?: "Unknown",
                            manufacturer = getJsonValue(resultJson, "manufacturer") ?: getJsonValue(resultJson, "brand") ?: "Unknown",
                            brand = getJsonValue(resultJson, "brand") ?: "Unknown",
                            weight = getJsonValue(resultJson, "weight") ?: "Unknown",
                            packagingType = getJsonValue(resultJson, "packagingType") ?: "Unknown",
                            country = getJsonValue(resultJson, "country") ?: "Unknown",
                            variant = getJsonValue(resultJson, "variant") ?: "",
                            type = getJsonValue(resultJson, "type") ?: getJsonValue(resultJson, "category") ?: "Unknown",
                            fragranceFlavor = getJsonValue(resultJson, "fragranceFlavor") ?: "",
                            promotion = getJsonValue(resultJson, "promotion") ?: "",
                            addons = getJsonValue(resultJson, "addons") ?: "",
                            tagline = getJsonValue(resultJson, "tagline") ?: "",
                            smartTranscript = "Extracted via High-Speed OCR and Gemini Vision Intelligent Audit Pipeline."
                        )
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error doing analyzeProductWithOcrPipeline: ${e.message}", e)
        }
        return null
    }
}
