package com.example.util

import java.util.Locale
import java.util.regex.Pattern

data class ImdbFields(
    val itemName: String?,
    val barcode: String?,
    val manufacturer: String?,
    val brand: String?,
    val weight: String?,
    val packagingType: String?,
    val country: String?,
    val variant: String?,
    val type: String?,
    val fragranceFlavor: String?,
    val promotion: String?,
    val addons: String?,
    val tagline: String?,
    val smartTranscript: String? = null
)

object TextAnalyzer {

    fun analyzeText(text: String): ImdbFields {
        val lowercaseText = text.lowercase(Locale.US)

        // 1. Barcode extraction (8 to 14 digit identifiers, e.g., UPC or EAN)
        val barcodePattern = Pattern.compile("(?:\\bbarcode\\b|\\bupc\\b|\\bean\\b|\\bcode\\b)[\\s:\\-#]*([0-9]{8,14})\\b|" +
                "\\b([0-9]{12,13})\\b|\\b([0-9]{8})\\b")
        val barcodeMatcher = barcodePattern.matcher(text)
        var barcode: String? = null
        if (barcodeMatcher.find()) {
            barcode = barcodeMatcher.group(1) ?: barcodeMatcher.group(2) ?: barcodeMatcher.group(3)
        }
        // If still null, try finding any 10-13 digit sequential numbers as backup
        if (barcode == null) {
            val backupPattern = Pattern.compile("\\b(\\d{10,13})\\b")
            val backupMatcher = backupPattern.matcher(text)
            if (backupMatcher.find()) {
                barcode = backupMatcher.group(1)
            }
        }

        // 2. Weight and Unit extraction (e.g. 500g, 1L, 12 Fl Oz, 200 ml, 100 tablets)
        val weightPattern = Pattern.compile(
            "\\b(\\d+(?:\\.\\d+)?)\\s*(g|mg|kg|oz|lbs?|fl\\.?\\s*oz|l|ml|liters?|tablets|tabs|capsules|caps|sheets)\\b",
            Pattern.CASE_INSENSITIVE
        )
        val weightMatcher = weightPattern.matcher(text)
        var weightUnit: String? = null
        if (weightMatcher.find()) {
            weightUnit = "${weightMatcher.group(1)} ${weightMatcher.group(2)}"
        }

        // 3. Country of origin detection (e.g., Made in Germany, Product of USA)
        val countryPattern = Pattern.compile(
            "(?:made\\s+in|product\\s+of|origin[:\\s]+)([a-zA-Z\\s]{3,20})",
            Pattern.CASE_INSENSITIVE
        )
        val countryMatcher = countryPattern.matcher(text)
        var countryOfOrigin: String? = null
        if (countryMatcher.find()) {
            countryOfOrigin = countryMatcher.group(1)?.trim()
        }
        // Look for common countries standalone in the text if no prefix is matched
        if (countryOfOrigin == null) {
            val countries = listOf("usa", "germany", "japan", "china", "france", "canada", "italy", "switzerland", "uk", "mexico", "india")
            for (c in countries) {
                if (lowercaseText.contains(c)) {
                    countryOfOrigin = c
                    break
                }
            }
        }
        countryOfOrigin = ImdbNormalizer.standardizeCountry(countryOfOrigin)

        // 4. Packaging Type detection
        var packagingType: String? = null
        val packagings = listOf("bottle", "can", "box", "pouch", "tube", "bag", "jar", "carton", "tub", "pack")
        for (p in packagings) {
            if (lowercaseText.contains(p)) {
                packagingType = p
                break
            }
        }
        packagingType = ImdbNormalizer.standardizePackaging(packagingType)

        // 5. Promotional message detection (Discounts, savings, taglines)
        val promoPattern = Pattern.compile(
            "(?:save|off|free|discount|promo|bonus|extra|special|only\\s+\\$|%\\s+more|coupon)\\b[^\\n.]{2,30}",
            Pattern.CASE_INSENSITIVE
        )
        val promoMatcher = promoPattern.matcher(text)
        var promotionalMessages: String? = null
        if (promoMatcher.find()) {
            promotionalMessages = promoMatcher.group()?.trim()
        }

        // 6. Brand Matching
        var brand: String? = null
        val brands = listOf("coca", "coke", "pepsi", "nestle", "heinz", "nike", "loreal", "colgate", "unilever", "starbucks", "tide")
        for (b in brands) {
            if (lowercaseText.contains(b)) {
                brand = b
                break
            }
        }
        // If not matched, try retrieving the first non-numeric word block as a reasonable brand approximation
        if (brand == null) {
            val firstWordPattern = Pattern.compile("\\b([a-zA-Z]{3,15})\\b")
            val fwMatcher = firstWordPattern.matcher(text)
            if (fwMatcher.find()) {
                brand = fwMatcher.group(1)
            }
        }
        brand = ImdbNormalizer.standardizeBrand(brand)

        // 7. Manufacturer Extraction
        val manufacturerPattern = Pattern.compile(
            "(?:manufactured\\s+by|mfd\\s+by|distributed\\s+by|dist\\.?\\s+by|packed\\s+for)[:\\s]+([a-zA-Z0-9\\s,]{3,30})",
            Pattern.CASE_INSENSITIVE
        )
        val manufacturerMatcher = manufacturerPattern.matcher(text)
        var manufacturer: String? = null
        if (manufacturerMatcher.find()) {
            manufacturer = manufacturerMatcher.group(1)?.trim()
        }
        if (manufacturer.isNullOrBlank()) {
            manufacturer = brand ?: "Unknown Manufacturer"
        }

        // 8. Category type extraction
        var categoryType: String? = null
        val categoriesKeywords = mapOf(
            "tea" to "Beverages", "coffee" to "Beverages", "juice" to "Beverages", "water" to "Beverages", "soda" to "Beverages", "cola" to "Beverages", "beer" to "Beverages",
            "cereal" to "Food & Snacks", "chips" to "Food & Snacks", "snack" to "Food & Snacks", "cookie" to "Food & Snacks", "chocolate" to "Food & Snacks", "soup" to "Food & Snacks", "pasta" to "Food & Snacks",
            "shampoo" to "Health & Beauty", "soap" to "Health & Beauty", "cream" to "Health & Beauty", "serum" to "Health & Beauty", "toothpaste" to "Health & Beauty", "vitamin" to "Health & Beauty",
            "detergent" to "Household Care", "spray" to "Household Care", "cleaner" to "Household Care", "dish" to "Household Care",
            "cable" to "Electronics", "usb" to "Electronics", "charger" to "Electronics"
        )
        for ((k, c) in categoriesKeywords) {
            if (lowercaseText.contains(k)) {
                categoryType = c
                break
            }
        }
        categoryType = ImdbNormalizer.standardizeCategory(categoryType)

        // 9. Segment Type extraction
        var segmentType: String? = null
        val segments = listOf("organic", "premium", "value", "gold", "signature", "budget", "eco")
        for (s in segments) {
            if (lowercaseText.contains(s)) {
                segmentType = s
                break
            }
        }
        segmentType = ImdbNormalizer.standardizeSegment(segmentType)

        // 10. Product Name estimation
        // Look for the line that stands out as the main label name (not copyright, not weight, etc.)
        val lines = text.split("\n").map { it.trim() }.filter { it.length > 3 && !it.contains("made in", true) && !it.contains("distrib", true) }
        var productName = lines.firstOrNull { l ->
            !l.any { it.isDigit() } && l.uppercase() == l
        } ?: lines.firstOrNull { l -> !l.any { it.isDigit() } } ?: lines.firstOrNull() ?: "Unknown"
        
        // Remove brand prefix if redundant
        if (brand != null && brand != "Unknown" && productName.startsWith(brand, ignoreCase = true) && productName.length > brand.length + 2) {
            productName = productName.substring(brand.length).trim().replace("^[^a-zA-Z]+".toRegex(), "")
        }
        productName = if (productName == "Standard Product Item" || productName.isBlank()) {
            "Unknown"
        } else {
            productName.trim().split(" ").joinToString(" ") { it.replaceFirstChar { char -> char.uppercase() } }
        }

        return ImdbFields(
            itemName = productName,
            barcode = barcode ?: "Unknown",
            manufacturer = if (manufacturer.isNullOrBlank() || manufacturer == "Unknown Manufacturer") "Unknown" else manufacturer,
            brand = brand ?: "Unknown",
            weight = weightUnit ?: "Unknown",
            packagingType = packagingType ?: "Unknown",
            country = countryOfOrigin ?: "Unknown",
            variant = "",
            type = categoryType ?: "Unknown",
            fragranceFlavor = "",
            promotion = promotionalMessages ?: "",
            addons = "",
            tagline = ""
        )
    }
}
