package com.example.util

import java.util.Locale

object ImdbNormalizer {

    // Centralized taxonomy definitions
    val STANDARD_CATEGORIES = listOf(
        "Beverages",
        "Food & Snacks",
        "Household Care",
        "Health & Beauty",
        "Electronics",
        "Apparel & Shoes",
        "Office Supplies"
    )

    val STANDARD_SEGMENTS = listOf(
        "Premium",
        "Standard",
        "Value",
        "Organic / Eco-Friendly"
    )

    val STANDARD_PACKAGING = listOf(
        "Bottle",
        "Box",
        "Can",
        "Pouch",
        "Tube",
        "Bag",
        "Jar",
        "Carton",
        "Tub"
    )

    val STANDARD_COUNTRIES = listOf(
        "United States",
        "United Kingdom",
        "Germany",
        "Switzerland",
        "France",
        "Canada",
        "Japan",
        "China",
        "India",
        "Mexico"
    )

    /**
     * Standardizes brand names using a centralized dictionary mapping to eliminate variations.
     */
    fun standardizeBrand(rawBrand: String?): String {
        if (rawBrand.isNullOrBlank()) return "Unknown"
        val clean = rawBrand.lowercase(Locale.US).trim()
        if (clean == "unknown" || clean == "needs review") return "Unknown"
        
        return when {
            clean.contains("coca") || clean.contains("coke") -> "Coca-Cola"
            clean.contains("pepsi") -> "PepsiCo"
            clean.contains("nestle") || clean.contains("nestlé") -> "Nestlé"
            clean.contains("heinz") -> "Heinz"
            clean.contains("nike") -> "Nike"
            clean.contains("loreal") || clean.contains("l'oreal") -> "L'Oréal"
            clean.contains("procter") || clean.contains("p&g") || clean.contains("gamble") -> "P&G"
            clean.contains("colgate") -> "Colgate"
            clean.contains("unilever") -> "Unilever"
            clean.contains("kraft") -> "Kraft Heinz"
            clean.contains("kellogg") -> "Kellogg's"
            clean.contains("starbucks") -> "Starbucks"
            else -> rawBrand.trim().split(" ").joinToString(" ") { it.replaceFirstChar { char -> char.uppercase() } }
        }
    }

    /**
     * Standardizes categories.
     */
    fun standardizeCategory(rawCategory: String?): String {
        if (rawCategory.isNullOrBlank()) return "Unknown"
        val clean = rawCategory.lowercase(Locale.US).trim()
        if (clean == "unknown" || clean == "needs review") return "Unknown"

        for (std in STANDARD_CATEGORIES) {
            if (std.lowercase(Locale.US) == clean) return std
        }

        return when {
            clean.contains("drink") || clean.contains("beverage") || clean.contains("water") || 
            clean.contains("soda") || clean.contains("juice") || clean.contains("tea") || clean.contains("beer") -> "Beverages"
            clean.contains("food") || clean.contains("snack") || clean.contains("candy") || clean.contains("cereal") ||
            clean.contains("pasta") || clean.contains("cookie") || clean.contains("bread") || clean.contains("supplement") -> "Food & Snacks"
            clean.contains("soap") || clean.contains("shampoo") || clean.contains("lotion") || clean.contains("beauty") ||
            clean.contains("makeup") || clean.contains("toothpaste") || clean.contains("vitamin") -> "Health & Beauty"
            clean.contains("cleaner") || clean.contains("detergent") || clean.contains("household") ||
            clean.contains("bleach") || clean.contains("dish") -> "Household Care"
            clean.contains("phone") || clean.contains("cable") || clean.contains("device") || clean.contains("electric") -> "Electronics"
            else -> rawCategory.trim().split(" ").joinToString(" ") { it.replaceFirstChar { char -> char.uppercase() } }
        }
    }

    /**
     * Standardizes segment type.
     */
    fun standardizeSegment(rawSegment: String?): String {
        if (rawSegment.isNullOrBlank()) return "Unknown"
        val clean = rawSegment.lowercase(Locale.US).trim()
        if (clean == "unknown" || clean == "needs review") return "Unknown"

        for (std in STANDARD_SEGMENTS) {
            if (std.lowercase(Locale.US).contains(clean) || clean.contains(std.lowercase(Locale.US))) return std
        }

        return when {
            clean.contains("org") || clean.contains("eco") || clean.contains("bio") || clean.contains("green") -> "Organic / Eco-Friendly"
            clean.contains("prem") || clean.contains("lux") || clean.contains("gold") || clean.contains("signature") -> "Premium"
            clean.contains("val") || clean.contains("cheap") || clean.contains("budget") || clean.contains("save") -> "Value"
            else -> "Unknown"
        }
    }

    /**
     * Standardizes packaging type.
     */
    fun standardizePackaging(rawPackaging: String?): String {
        if (rawPackaging.isNullOrBlank()) return "Unknown"
        val clean = rawPackaging.lowercase(Locale.US).trim()
        if (clean == "unknown" || clean == "needs review") return "Unknown"

        for (std in STANDARD_PACKAGING) {
            if (std.lowercase(Locale.US) == clean || clean.contains(std.lowercase(Locale.US))) return std
        }

        return when {
            clean.contains("bot") || clean.contains("plastic") -> "Bottle"
            clean.contains("can") || clean.contains("tin") -> "Can"
            clean.contains("bag") || clean.contains("sack") -> "Bag"
            clean.contains("box") || clean.contains("cart") -> "Box"
            clean.contains("pouch") || clean.contains("sachet") -> "Pouch"
            clean.contains("tube") -> "Tube"
            clean.contains("jar") -> "Jar"
            else -> "Unknown"
        }
    }

    /**
     * Standardizes Country of Origin.
     */
    fun standardizeCountry(rawCountry: String?): String {
        if (rawCountry.isNullOrBlank()) return "Unknown"
        val clean = rawCountry.lowercase(Locale.US).trim()
        if (clean == "unknown" || clean == "needs review" || clean == "unknown country") return "Unknown"

        return when {
            clean.contains("usa") || clean.contains("united states") || clean.contains("u.s") || clean.contains("america") -> "United States"
            clean.contains("uk") || clean.contains("united kingdom") || clean.contains("gbr") || clean.contains("britain") -> "United Kingdom"
            clean.contains("germany") || clean.contains("deutschland") || clean.contains("ger") -> "Germany"
            clean.contains("swiss") || clean.contains("switzerland") || clean.contains("che") -> "Switzerland"
            clean.contains("france") || clean.contains("fra") -> "France"
            clean.contains("canada") || clean.contains("can") -> "Canada"
            clean.contains("japan") || clean.contains("jpn") -> "Japan"
            clean.contains("china") || clean.contains("chn") -> "China"
            clean.contains("india") || clean.contains("ind") -> "India"
            clean.contains("mexico") || clean.contains("mex") -> "Mexico"
            else -> rawCountry.trim().split(" ").joinToString(" ") { it.replaceFirstChar { char -> char.uppercase() } }
        }
    }

    /**
     * Deduces country of origin based on the EAN/UPC prefix.
     */
    fun deduceCountryFromBarcode(barcode: String?): String {
        if (barcode.isNullOrBlank()) return "Unknown"
        val clean = barcode.replace("\\D".toRegex(), "")
        if (clean.length < 3) return "Unknown"
        val prefix2 = clean.take(2).toIntOrNull() ?: return "Unknown"
        val prefix3 = clean.take(3).toIntOrNull() ?: return "Unknown"
        return when {
            prefix2 in 0..13 -> "United States"
            prefix2 in 30..37 -> "France"
            prefix2 in 40..44 -> "Germany"
            prefix2 in 45..49 -> "Japan"
            prefix2 == 46 -> "Russia"
            prefix2 == 50 -> "United Kingdom"
            prefix2 == 54 -> "Belgium"
            prefix2 == 76 -> "Switzerland"
            prefix2 in 80..83 -> "Italy"
            prefix2 == 84 -> "Spain"
            prefix3 == 880 -> "South Korea"
            prefix3 == 890 -> "India"
            prefix2 in 690..699 -> "China"
            prefix2 == 93 -> "Australia"
            prefix2 == 94 -> "New Zealand"
            else -> "Unknown"
        }
    }
}
