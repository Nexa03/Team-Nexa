package com.example.util

import android.content.Context
import android.graphics.*
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream

object ImageProcessor {

    fun preprocessImage(context: Context, imageUri: Uri, applyEnhancements: Boolean): Uri {
        // Safe, ultra-fast downsampling directly during decoding
        val bitmap = decodeSampledBitmap(context, imageUri, 1280, 1280) ?: return imageUri

        var processedBitmap = bitmap

        // Ensure max width is respected
        processedBitmap = scaleBitmapToMax(processedBitmap, 1280)

        if (applyEnhancements) {
            // Optional upscaling for images under 800px width
            processedBitmap = scaleBitmapToMin(processedBitmap, 800)

            // Grayscale conversion and Contrast enhancement
            processedBitmap = applyGrayscaleAndContrast(processedBitmap)
        }

        // Save preprocessed bitmap to cache
        val cacheFile = File(context.cacheDir, "preprocessed_${System.currentTimeMillis()}.jpg")
        FileOutputStream(cacheFile).use { out ->
            processedBitmap.compress(Bitmap.CompressFormat.JPEG, 90, out)
        }

        // Return cached URI
        return Uri.fromFile(cacheFile)
    }

    private fun decodeSampledBitmap(context: Context, imageUri: Uri, reqWidth: Int, reqHeight: Int): Bitmap? {
        val contentResolver = context.contentResolver
        return try {
            val options = BitmapFactory.Options().apply {
                inJustDecodeBounds = true
            }
            contentResolver.openInputStream(imageUri).use { input ->
                BitmapFactory.decodeStream(input, null, options)
            }

            var inSampleSize = 1
            if (options.outHeight > reqHeight || options.outWidth > reqWidth) {
                val halfHeight = options.outHeight / 2
                val halfWidth = options.outWidth / 2
                while (halfHeight / inSampleSize >= reqHeight && halfWidth / inSampleSize >= reqWidth) {
                    inSampleSize *= 2
                }
            }

            options.inSampleSize = inSampleSize
            options.inJustDecodeBounds = false

            contentResolver.openInputStream(imageUri).use { input ->
                BitmapFactory.decodeStream(input, null, options)
            }
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun scaleBitmapToMax(src: Bitmap, maxWidth: Int): Bitmap {
        if (src.width <= maxWidth) return src
        val ratio = maxWidth.toFloat() / src.width
        val targetHeight = (src.height * ratio).toInt()
        return Bitmap.createScaledBitmap(src, maxWidth, targetHeight, true)
    }

    private fun scaleBitmapToMin(src: Bitmap, minWidth: Int): Bitmap {
        if (src.width >= minWidth) return src
        val ratio = minWidth.toFloat() / src.width
        val targetHeight = (src.height * ratio).toInt()
        return Bitmap.createScaledBitmap(src, minWidth, targetHeight, true)
    }

    private fun applyGrayscaleAndContrast(src: Bitmap): Bitmap {
        val width = src.width
        val height = src.height

        val dest = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(dest)
        val paint = Paint()

        // Saturation 0 is Grayscale
        // Contrast multiplier of 1.4f enhances text clarity
        // Brightness translate offset adjusts values
        val scale = 1.4f
        val translate = -15f
        val contrastMatrix = floatArrayOf(
            scale, 0f, 0f, 0f, translate,
            0f, scale, 0f, 0f, translate,
            0f, 0f, scale, 0f, translate,
            0f, 0f, 0f, 1f, 0f
        )

        val grayscaleMatrix = ColorMatrix().apply { setSaturation(0f) }
        val combinedMatrix = ColorMatrix().apply {
            set(contrastMatrix)
            postConcat(grayscaleMatrix)
        }

        paint.colorFilter = ColorMatrixColorFilter(combinedMatrix)
        canvas.drawBitmap(src, 0f, 0f, paint)

        return dest
    }
}
