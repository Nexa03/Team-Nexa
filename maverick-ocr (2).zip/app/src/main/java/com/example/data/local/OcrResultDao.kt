package com.example.data.local

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface OcrResultDao {
    @Query("SELECT * FROM ocr_results ORDER BY timestamp DESC")
    fun getAllResults(): Flow<List<OcrResultEntity>>

    @Query("SELECT * FROM ocr_results ORDER BY timestamp DESC")
    suspend fun getAllResultsDirect(): List<OcrResultEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertResult(result: OcrResultEntity): Long

    @Query("SELECT * FROM ocr_results WHERE barcode = :barcode AND itemName IS NOT NULL AND itemName != '' LIMIT 1")
    suspend fun findByBarcode(barcode: String): OcrResultEntity?

    @Delete
    suspend fun deleteResult(result: OcrResultEntity)

    @Query("DELETE FROM ocr_results")
    suspend fun clearAll()
}
