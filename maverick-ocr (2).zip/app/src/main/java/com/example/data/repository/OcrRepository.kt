package com.example.data.repository

import android.content.Context
import android.net.Uri
import android.util.Log
import com.example.data.local.OcrResultDao
import com.example.data.local.OcrResultEntity
import com.example.util.ImageProcessor
import com.example.util.TextAnalyzer
import com.example.util.ImdbNormalizer
import com.example.util.ImdbFields
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class OcrRepository(
    private val context: Context,
    private val ocrResultDao: OcrResultDao
) {
    val allResults: Flow<List<OcrResultEntity>> = ocrResultDao.getAllResults()

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(5, TimeUnit.SECONDS)
        .writeTimeout(5, TimeUnit.SECONDS)
        .build()

    /**
     * Look up barcode directly on the Open Food Facts API (Ultra Fast)
     */
    fun lookupBarcodeOpenFoodFacts(barcode: String): ImdbFields? {
        if (barcode.isBlank()) return null
        try {
            val url = "https://world.openfoodfacts.org/api/v0/product/$barcode.json"
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "MaverickBarcodeScanner/1.0 (Android Hackathon App)")
                .build()

            httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return null
                val responseBody = response.body?.string() ?: return null
                val json = JSONObject(responseBody)
                if (json.optInt("status", 0) != 1) {
                    return null
                }
                val product = json.optJSONObject("product") ?: return null

                val code = product.optString("code", barcode)
                val productName = product.optString("product_name")?.ifBlank { null }
                    ?: product.optString("product_name_en")?.ifBlank { null }
                    ?: "Unknown"
                
                val brands = product.optString("brands")?.ifBlank { null } ?: "Unknown"
                val manufacturer = product.optString("manufacturers")?.ifBlank { null } ?: brands

                val categoriesStr = product.optString("categories") ?: ""
                val categoriesList = categoriesStr.split(",").map { it.trim() }.filter { it.isNotEmpty() }
                val firstCategory = categoriesList.firstOrNull() ?: "Unknown"
                val secondCategory = if (categoriesList.size > 1) categoriesList[1] else "Unknown"

                val weight = product.optString("product_quantity")?.ifBlank { null }
                    ?: product.optString("quantity")?.ifBlank { null }
                    ?: "Unknown"
                
                val packaging = product.optString("packaging")?.ifBlank { null } ?: "Unknown"
                val countries = product.optString("countries")?.ifBlank { null } ?: ImdbNormalizer.deduceCountryFromBarcode(code)
                val promotion = product.optString("labels")?.ifBlank { "" } ?: ""

                return ImdbFields(
                    itemName = productName,
                    barcode = code,
                    manufacturer = manufacturer,
                    brand = ImdbNormalizer.standardizeBrand(brands),
                    weight = weight,
                    packagingType = ImdbNormalizer.standardizePackaging(packaging),
                    country = ImdbNormalizer.standardizeCountry(countries),
                    variant = "",
                    type = ImdbNormalizer.standardizeCategory(firstCategory),
                    fragranceFlavor = "",
                    promotion = if (promotion.isNotBlank()) promotion else "Verified Barcode Register Record",
                    addons = "",
                    tagline = "",
                    smartTranscript = "Decoded live via Open Food Facts Global API.\nDetails:\nName: $productName\nBrand: $brands\nCategory: $firstCategory"
                )
            }
        } catch (e: Exception) {
            Log.e("OcrRepository", "Open Food Facts lookup failed: ${e.message}")
        }
        return null
    }

    /**
     * Look up barcode directly on UPCitemdb trial API
     */
    fun lookupBarcodeUpcItemDb(barcode: String): ImdbFields? {
        if (barcode.isBlank()) return null
        try {
            val url = "https://api.upcitemdb.com/prod/trial/lookup?upc=$barcode"
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "MaverickBarcodeScanner/1.0 (Android Hackathon App)")
                .build()

            httpClient.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return null
                val responseBody = response.body?.string() ?: return null
                val json = JSONObject(responseBody)
                val code = json.optString("code", "")
                if (code != "OK") return null
                val items = json.optJSONArray("items") ?: return null
                if (items.length() == 0) return null
                val item = items.getJSONObject(0)

                val title = item.optString("title").ifBlank { null } ?: "Unknown"
                val brand = item.optString("brand").ifBlank { null } ?: "Unknown"
                val manufacturer = item.optString("publisher").ifBlank { null } ?: brand
                
                val categoryStr = item.optString("category") ?: ""
                val categoriesList = categoryStr.split("/").map { it.trim() }.filter { it.isNotEmpty() }
                val firstCategory = categoriesList.firstOrNull() ?: "Unknown"
                val secondCategory = if (categoriesList.size > 1) categoriesList[1] else "Unknown"

                var imageUrl: String? = null
                val imagesArray = item.optJSONArray("images")
                if (imagesArray != null && imagesArray.length() > 0) {
                    imageUrl = imagesArray.optString(0)
                }

                return ImdbFields(
                    itemName = title,
                    barcode = barcode,
                    manufacturer = manufacturer,
                    brand = ImdbNormalizer.standardizeBrand(brand),
                    weight = "Unknown",
                    packagingType = "Unknown",
                    country = ImdbNormalizer.standardizeCountry(ImdbNormalizer.deduceCountryFromBarcode(barcode)),
                    variant = "",
                    type = ImdbNormalizer.standardizeCategory(firstCategory),
                    fragranceFlavor = "",
                    promotion = "Verified live via UPCitemdb API.",
                    addons = "",
                    tagline = "",
                    smartTranscript = "Decoded live via UPCitemdb.\nTitle: $title\nBrand: $brand\nCategory: $categoryStr" + (if (imageUrl != null) "\nImage: $imageUrl" else "")
                )
            }
        } catch (e: Exception) {
            Log.e("OcrRepository", "UPCitemdb lookup failed: ${e.message}")
        }
        return null
    }

    /**
     * Direct live barcode lookup (0ms local cache, 500ms API)
     */
    suspend fun processBarcodeLookup(
        barcode: String,
        streakDayCount: Int,
        autoSave: Boolean
    ): OcrResultEntity = withContext(Dispatchers.IO) {
        // Step 1: Instant Local Cache Lookup
        val cached = ocrResultDao.findByBarcode(barcode)
        if (cached != null) {
            val freshEntity = cached.copy(
                id = 0, // Reset for auto increment
                timestamp = System.currentTimeMillis(),
                confidence = "UPCitemdb", // Reuse original source or label
                streakDayCount = streakDayCount
            )
            if (autoSave) {
                val newId = ocrResultDao.insertResult(freshEntity)
                return@withContext freshEntity.copy(id = newId.toInt())
            }
            return@withContext freshEntity
        }

        // Step 2: UPCitemdb API (Primary Source)
        var sourceLabel = "UPCitemdb"
        var fields: ImdbFields? = lookupBarcodeUpcItemDb(barcode)

        // Step 3: Open Food Facts API (Fallback)
        if (fields == null) {
            fields = lookupBarcodeOpenFoodFacts(barcode)
            if (fields != null) {
                sourceLabel = "Open Food Facts"
            }
        }

        // Step 4: Fallback Gemini lookup (If both failed, we can also use Gemini as a text lookup fallback)
        if (fields == null && com.example.util.GeminiClient.isGeminiAvailable()) {
            fields = com.example.util.GeminiClient.lookupBarcodeWithGemini(barcode)
            if (fields != null) {
                sourceLabel = "Gemini"
            }
        }

        val name = fields?.itemName ?: ""
        val br = fields?.brand ?: ""
        val mn = fields?.manufacturer ?: br
        val wt = fields?.weight ?: ""
        val pk = fields?.packagingType ?: ""
        val co = fields?.country ?: ""
        val vr = fields?.variant ?: ""
        val ty = fields?.type ?: ""
        val ff = fields?.fragranceFlavor ?: ""
        val pr = fields?.promotion ?: ""
        val ad = fields?.addons ?: ""
        val tg = fields?.tagline ?: ""

        // If lookup failed completely, source is "Manual" or not found
        if (fields == null) {
            sourceLabel = "Manual"
        }

        val labelText = fields?.smartTranscript ?: "Live Barcode Scan decoded barcode: $barcode.\nDatabase record not found. Manual entry is required."

        val entity = OcrResultEntity(
            imageUri = "", // No photo taken in live scanning!
            processedImageUri = null,
            rawText = labelText,
            wordCount = labelText.split("\\s+".toRegex()).size,
            charCount = labelText.length,
            confidence = sourceLabel, // Store Source Indicator
            timestamp = System.currentTimeMillis(),
            streakDayCount = streakDayCount,
            itemName = name,
            barcode = barcode,
            manufacturer = mn,
            brand = br,
            weight = wt,
            packagingType = pk,
            country = co,
            variant = vr,
            type = ty,
            fragranceFlavor = ff,
            promotion = pr,
            addons = ad,
            tagline = tg,
            lowConfidenceFlag = fields == null, // true if lookup failed entirely and requires manual input or fallback
            standardizedFlag = true
        )

        // Keep local cache size healthy
        enforceCacheLimit()

        if (autoSave && fields != null) {
            val id = ocrResultDao.insertResult(entity)
            entity.copy(id = id.toInt())
        } else {
            entity
        }
    }

    /**
     * Quaternary Source: Gemini Vision Fallback when DB lookup failed
     */
    suspend fun processGeminiVisionFallback(
        imageUri: Uri,
        barcode: String?,
        streakDayCount: Int,
        autoSave: Boolean
    ): OcrResultEntity = withContext(Dispatchers.IO) {
        val fields = com.example.util.GeminiClient.analyzeProductImageOnly(context, imageUri)
        val name = fields?.itemName ?: ""
        val br = fields?.brand ?: ""
        val mn = fields?.manufacturer ?: br
        val wt = fields?.weight ?: ""
        val pk = fields?.packagingType ?: ""
        val co = fields?.country ?: ""
        val vr = fields?.variant ?: ""
        val ty = fields?.type ?: ""
        val ff = fields?.fragranceFlavor ?: ""
        val pr = fields?.promotion ?: ""
        val ad = fields?.addons ?: ""
        val tg = fields?.tagline ?: ""
        val labelText = fields?.smartTranscript ?: "Advanced Gemini Vision fallback scan completed."

        val entity = OcrResultEntity(
            imageUri = imageUri.toString(),
            processedImageUri = null,
            rawText = labelText,
            wordCount = labelText.split("\\s+".toRegex()).size,
            charCount = labelText.length,
            confidence = "Gemini",
            timestamp = System.currentTimeMillis(),
            streakDayCount = streakDayCount,
            barcode = barcode ?: fields?.barcode ?: "",
            itemName = name,
            manufacturer = mn,
            brand = br,
            weight = wt,
            packagingType = pk,
            country = co,
            variant = vr,
            type = ty,
            fragranceFlavor = ff,
            promotion = pr,
            addons = ad,
            tagline = tg,
            lowConfidenceFlag = false, // Resolve completed!
            standardizedFlag = true
        )

        enforceCacheLimit()

        if (autoSave) {
            val id = ocrResultDao.insertResult(entity)
            entity.copy(id = id.toInt())
        } else {
            entity
        }
    }

    /**
     * Premium Image Upload OCR & Gemini Pipeline
     */
    suspend fun processOcrPipelineImageUpload(
        imageUri: Uri,
        streakDayCount: Int,
        autoSave: Boolean
    ): OcrResultEntity = withContext(Dispatchers.IO) {
        var rawExtracted = ""
        try {
            val recognizer = TextRecognition.getClient(TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).let { TextRecognizerOptions.DEFAULT_OPTIONS })
            val inputImage = InputImage.fromFilePath(context, imageUri)
            val result = suspendCancellableCoroutine { continuation ->
                val localRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
                localRecognizer.process(inputImage)
                    .addOnSuccessListener { textResult ->
                        continuation.resume(textResult.text)
                    }
                    .addOnFailureListener { e ->
                        continuation.resume("") // fallback
                    }
            }
            rawExtracted = result
        } catch (e: Exception) {
            Log.e("OcrRepository", "Local ML Kit OCR failed: ${e.message}")
        }

         val fields = com.example.util.GeminiClient.analyzeProductWithOcrPipeline(context, imageUri, rawExtracted)
         val name = fields?.itemName ?: ""
         val br = fields?.brand ?: ""
         val mn = fields?.manufacturer ?: br
         val wt = fields?.weight ?: ""
         val pk = fields?.packagingType ?: ""
         val co = fields?.country ?: ""
         val vr = fields?.variant ?: ""
         val ty = fields?.type ?: ""
         val ff = fields?.fragranceFlavor ?: ""
         val pr = fields?.promotion ?: ""
         val ad = fields?.addons ?: ""
         val tg = fields?.tagline ?: ""
         val labelText = fields?.smartTranscript ?: rawExtracted.ifBlank { "Smart scan finished." }
 
         val entity = OcrResultEntity(
             imageUri = imageUri.toString(),
             processedImageUri = null,
             rawText = labelText,
             wordCount = labelText.split("\\s+".toRegex()).size,
             charCount = labelText.length,
             confidence = "Gemini", // OCR / Gemini pipeline source identifier
             timestamp = System.currentTimeMillis(),
             streakDayCount = streakDayCount,
             barcode = fields?.barcode ?: "",
             itemName = name,
             manufacturer = mn,
             brand = br,
             weight = wt,
             packagingType = pk,
             country = co,
             variant = vr,
             type = ty,
             fragranceFlavor = ff,
             promotion = pr,
             addons = ad,
             tagline = tg,
             lowConfidenceFlag = fields == null,
             standardizedFlag = true
         )

        enforceCacheLimit()

        if (autoSave) {
            val id = ocrResultDao.insertResult(entity)
            entity.copy(id = id.toInt())
        } else {
            entity
        }
    }

    private suspend fun enforceCacheLimit() {
        try {
            // Note: If needs limit max cache item size, can delete oldest scans beyond 50 limit!
            val results = ocrResultDao.getAllResultsDirect()
            if (results.size >= 50) {
                val toDelete = results.drop(49)
                toDelete.forEach { ocrResultDao.deleteResult(it) }
            }
        } catch (e: Exception) {
            Log.e("OcrRepository", "Failed to enforce cache limit: ${e.message}")
        }
    }

    suspend fun processNewScan(
        imageUri: Uri,
        applyPreprocessing: Boolean,
        autoSave: Boolean,
        streakDayCount: Int
    ): OcrResultEntity = withContext(Dispatchers.IO) {
        val savedImageUri = copyUriToInternalStorage(context, imageUri, "scan_raw_${System.currentTimeMillis()}.jpg")

        val finalImageForOcr: Uri
        val savedProcessedUri: Uri?

        if (applyPreprocessing) {
            val processedUri = ImageProcessor.preprocessImage(context, savedImageUri, true)
            savedProcessedUri = copyUriToInternalStorage(context, processedUri, "scan_proc_${System.currentTimeMillis()}.jpg")
            finalImageForOcr = savedProcessedUri
        } else {
            // Apply downsampling only (standard performance constraint: downsample to 1280px max width)
            val downsampledUri = ImageProcessor.preprocessImage(context, savedImageUri, false)
            savedProcessedUri = null
            finalImageForOcr = downsampledUri
        }

        // Run local OCR and Barcode scan in parallel for high speed
        val ocrDeferred = async {
            try {
                performOcr(finalImageForOcr)
            } catch (e: Exception) {
                ""
            }
        }

        val barcodeDeferred = async {
            try {
                performBarcodeScan(finalImageForOcr)
            } catch (e: Exception) {
                null
            }
        }

        val extractedText = ocrDeferred.await()
        val detectedBarcode = barcodeDeferred.await()

        // 1. High-Speed Local DB Cache Lookup (0ms latency, fully offline-ready!)
        if (!detectedBarcode.isNullOrBlank()) {
            val cachedResult = ocrResultDao.findByBarcode(detectedBarcode)
            if (cachedResult != null) {
                val cachedEntity = cachedResult.copy(
                    id = 0, // Reset to 0 so Room auto-generates a new unique entry key
                    imageUri = savedImageUri.toString(),
                    processedImageUri = savedProcessedUri?.toString(),
                    confidence = "High (Instant Locally Cached)",
                    timestamp = System.currentTimeMillis(),
                    streakDayCount = streakDayCount
                )
                if (autoSave) {
                    val id = ocrResultDao.insertResult(cachedEntity)
                    return@withContext cachedEntity.copy(id = id.toInt())
                } else {
                    return@withContext cachedEntity
                }
            }
        }

        // 2. High-Speed Online Barcode Registry Lookup (Fast Text-Only Mode!)
        var geminiFields: com.example.util.ImdbFields? = null
        var usedGeminiTextLookup = false

        if (!detectedBarcode.isNullOrBlank() && com.example.util.GeminiClient.isGeminiAvailable()) {
            geminiFields = com.example.util.GeminiClient.lookupBarcodeWithGemini(detectedBarcode)
            if (geminiFields != null) {
                usedGeminiTextLookup = true
            }
        }

        // 3. Multimodal VLM Label Image Analyzer (Slower Fallback)
        var usedGeminiVlm = false
        if (geminiFields == null) {
            geminiFields = com.example.util.GeminiClient.extractWithGemini(context, finalImageForOcr, detectedBarcode)
            if (geminiFields != null) {
                usedGeminiVlm = true
            }
        }

        val usedGemini = geminiFields != null

        // If Gemini failed or is unavailable, use local Regex solver on extractedText and inject hardware barcode
        val localFields = com.example.util.TextAnalyzer.analyzeText(extractedText)
        val finalFields = geminiFields ?: if (!detectedBarcode.isNullOrBlank()) {
            localFields.copy(barcode = detectedBarcode)
        } else {
            localFields
        }

        // Count metrics
        val finalRawText = if (finalFields.smartTranscript != null) {
            finalFields.smartTranscript
        } else if (extractedText.isBlank() && usedGemini) {
            "[Direct Smart Scan Analysis Completed - High Definition Capture]"
        } else {
            extractedText
        }
        val wordCount = finalRawText.split("\\s+".toRegex()).filter { it.isNotBlank() }.size
        val charCount = finalRawText.length

        // Flag low confidence if barcode is auto-generated or name/brand is missing
        val isBarcodeGenerated = finalFields.barcode?.startsWith("BAR-NEW-") == true
        val isLowConfidence = isBarcodeGenerated || finalFields.itemName == "Standard Product Item" || finalFields.brand == "Unknown Brand" || (charCount < 10 && !usedGemini)

        val confidenceValue = when {
            usedGemini && !isLowConfidence -> "High"
            charCount > 30 && !isLowConfidence -> "High"
            charCount > 10 -> "Medium"
            else -> "Low"
        }

        val entity = OcrResultEntity(
            imageUri = savedImageUri.toString(),
            processedImageUri = savedProcessedUri?.toString(),
            rawText = finalRawText,
            wordCount = wordCount,
            charCount = charCount,
            confidence = confidenceValue,
            timestamp = System.currentTimeMillis(),
            streakDayCount = streakDayCount,
            itemName = finalFields.itemName,
            barcode = finalFields.barcode,
            manufacturer = finalFields.manufacturer,
            brand = finalFields.brand,
            weight = finalFields.weight,
            packagingType = finalFields.packagingType,
            country = finalFields.country,
            variant = finalFields.variant,
            type = finalFields.type,
            fragranceFlavor = finalFields.fragranceFlavor,
            promotion = finalFields.promotion,
            addons = finalFields.addons,
            tagline = finalFields.tagline,
            lowConfidenceFlag = isLowConfidence,
            standardizedFlag = true
        )

        if (autoSave) {
            val id = ocrResultDao.insertResult(entity)
            entity.copy(id = id.toInt())
        } else {
            entity
        }
    }

    suspend fun deleteResult(result: OcrResultEntity) = withContext(Dispatchers.IO) {
        // Delete image files associated with it
        deleteFileByUri(result.imageUri)
        result.processedImageUri?.let { deleteFileByUri(it) }
        ocrResultDao.deleteResult(result)
    }

    suspend fun updateResult(result: OcrResultEntity) = withContext(Dispatchers.IO) {
        ocrResultDao.insertResult(result)
    }

    suspend fun insertResultDirectly(result: OcrResultEntity): Long = withContext(Dispatchers.IO) {
        ocrResultDao.insertResult(result)
    }

    suspend fun clearAllHistory() = withContext(Dispatchers.IO) {
        ocrResultDao.clearAll()
        // Clean directory of images
        val scansDir = File(context.filesDir, "scans")
        if (scansDir.exists()) {
            scansDir.deleteRecursively()
        }
    }

    private suspend fun performBarcodeScan(uri: Uri): String? = suspendCancellableCoroutine { continuation ->
        try {
            val image = InputImage.fromFilePath(context, uri)
            val scanner = BarcodeScanning.getClient()
            scanner.process(image)
                .addOnSuccessListener { barcodes ->
                    if (continuation.isActive) {
                        val result = barcodes.firstOrNull()?.rawValue
                        continuation.resume(result)
                    }
                }
                .addOnFailureListener { e ->
                    if (continuation.isActive) {
                        continuation.resume(null)
                    }
                }
        } catch (e: Exception) {
            if (continuation.isActive) {
                continuation.resume(null)
            }
        }
    }

    private suspend fun performOcr(uri: Uri): String = suspendCancellableCoroutine { continuation ->
        try {
            val image = InputImage.fromFilePath(context, uri)
            val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            recognizer.process(image)
                .addOnSuccessListener { visionText ->
                    if (continuation.isActive) {
                        continuation.resume(visionText.text)
                    }
                }
                .addOnFailureListener { e ->
                    if (continuation.isActive) {
                        continuation.resumeWithException(e)
                    }
                }
        } catch (e: Exception) {
            if (continuation.isActive) {
                continuation.resumeWithException(e)
            }
        }
    }

    private fun copyUriToInternalStorage(context: Context, uri: Uri, fileName: String): Uri {
        val scansDir = File(context.filesDir, "scans").apply { mkdirs() }
        val destFile = File(scansDir, fileName)
        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(destFile).use { output ->
                input.copyTo(output)
            }
        }
        return Uri.fromFile(destFile)
    }

    private fun deleteFileByUri(uriString: String) {
        try {
            val uri = Uri.parse(uriString)
            uri.path?.let { File(it).apply { if (exists()) delete() } }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
