package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "ocr_results")
data class OcrResultEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val imageUri: String,
    val processedImageUri: String?,
    val rawText: String,
    val wordCount: Int,
    val charCount: Int,
    val confidence: String, // OCR confidence: "High", "Medium", "Low"
    val timestamp: Long,
    val streakDayCount: Int = 0,
    
    // Core 13 IMDB attributes (fully compatible with predictions sheet columns)
    val itemName: String? = null,
    val barcode: String? = null,
    val manufacturer: String? = null,
    val brand: String? = null,
    val weight: String? = null,
    val packagingType: String? = null,
    val country: String? = null,
    val variant: String? = null,
    val type: String? = null,
    val fragranceFlavor: String? = null,
    val promotion: String? = null,
    val addons: String? = null,
    val tagline: String? = null,
    
    // Control and feedback metrics
    val lowConfidenceFlag: Boolean = false, // True if barcode, name or brand is missing/weak and needs manual confirmation
    val standardizedFlag: Boolean = false  // True once standardized dictionary terms are applied
)

