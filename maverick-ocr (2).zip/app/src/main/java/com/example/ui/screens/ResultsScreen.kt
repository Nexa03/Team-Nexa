package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.example.data.local.OcrResultEntity
import com.example.ui.OcrViewModel
import java.io.File
import java.io.FileOutputStream

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ResultsScreen(
    viewModel: OcrViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentResult by viewModel.currentScanResult.collectAsState()
    val isAnalyzing by viewModel.isAnalyzing.collectAsState()

    var isEditMode by remember { mutableStateOf(false) }

    // Forms and launchers
    var cameraTempUri by remember { mutableStateOf<Uri?>(null) }

    fun getTempUri(): Uri {
        val cacheDir = context.cacheDir
        val tempFile = File(cacheDir, "gemini_fallback_capture_${System.currentTimeMillis()}.jpg")
        if (tempFile.exists()) tempFile.delete()
        tempFile.createNewFile()
        val authority = "${context.packageName}.fileprovider"
        return FileProvider.getUriForFile(context, authority, tempFile)
    }

    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            val barcode = currentResult?.barcode ?: ""
            viewModel.triggerGeminiVisionFallback(uri, barcode)
        }
    }

    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success ->
        if (success) {
            cameraTempUri?.let { uri ->
                val barcode = currentResult?.barcode ?: ""
                viewModel.triggerGeminiVisionFallback(uri, barcode)
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "CURRENT WORKSPACE",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.5.sp
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "PRODUCT DETAILS",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Black
                        )
                    }
                },
                actions = {
                    if (currentResult != null) {
                        IconButton(onClick = { isEditMode = !isEditMode }) {
                            Icon(
                                imageVector = if (isEditMode) Icons.Default.Check else Icons.Default.Edit,
                                contentDescription = if (isEditMode) "Done" else "Edit Fields",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                        IconButton(onClick = { viewModel.setCurrentScanResult(null) }) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Clear Result",
                                tint = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (isAnalyzing) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        CircularProgressIndicator()
                        Text(
                            text = "Analyzing product image...",
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else if (currentResult == null) {
                // Empty State with option to create manual entry or go scan
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Box(
                            modifier = Modifier
                                .size(80.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = null,
                                modifier = Modifier.size(40.dp),
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                        Spacer(modifier = Modifier.height(24.dp))
                        Text(
                            text = "Workspace is Empty",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Black,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Scan a barcode or upload an image in the SCANNER tab. Alternatively, you can create a blank retail master index entry manually.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(horizontal = 16.dp)
                        )
                        Spacer(modifier = Modifier.height(32.dp))
                        
                        Button(
                            onClick = {
                                val manualEntity = OcrResultEntity(
                                     imageUri = "",
                                     processedImageUri = null,
                                     rawText = "Manually created product index entry.",
                                     wordCount = 5,
                                     charCount = 37,
                                     confidence = "Manual",
                                     timestamp = System.currentTimeMillis(),
                                     itemName = "",
                                     barcode = "",
                                     manufacturer = "",
                                     brand = "",
                                     weight = "",
                                     packagingType = "",
                                     country = "",
                                     variant = "",
                                     type = "",
                                     fragranceFlavor = "",
                                     promotion = "",
                                     addons = "",
                                     tagline = ""
                                 )
                                 viewModel.setCurrentScanResult(manualEntity)
                                 isEditMode = true
                                 /*
                                    imageUri = "",
                                    processedImageUri = null,
                                    rawText = "Manually created product index entry.",
                                    wordCount = 5,
                                    charCount = 37,
                                    confidence = "Manual",
                                    timestamp = System.currentTimeMillis(),
                                    barcode = "",
                                     itemName = "",
                                     barcode = "",
                                    barcode = "",
                                    manufacturer = "",
                                    brand = "",
                                    weight = "",
                                    packagingType = "",
                                    country = "",
                                    variant = "",
                                    type = "",
                                    fragranceFlavor = "",
                                    promotion = "",
                                    addons = "",
                                    tagline = ""
                                )
                                */
                                 viewModel.setCurrentScanResult(manualEntity)
                                isEditMode = true
                            },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth(0.85f)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Create Manual Entry", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            } else {
                val result = currentResult!!
                val isDbNotFound = result.lowConfidenceFlag && (result.itemName.isNullOrBlank() || result.itemName == "Standard Retail Product" || result.itemName == "Unknown" || result.itemName == "") && result.confidence == "Manual"

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(bottom = 100.dp, start = 16.dp, end = 16.dp, top = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Source Indicator Banner
                    SourceIndicatorBanner(source = result.confidence)

                    if (isDbNotFound) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.25f)),
                            modifier = Modifier.fillMaxWidth(),
                            border = borderStroke(MaterialTheme.colorScheme.error.copy(alpha = 0.3f))
                        ) {
                            Column(
                                modifier = Modifier.padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = "Product Not Found in Databases!",
                                    fontWeight = FontWeight.Bold,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.error
                                )
                                Text(
                                    text = "Both UPCitemdb and Open Food Facts APIs found no matches for barcode ${result.barcode}. Try Gemini Vision Advanced Fallback by capturing or selecting a product image!",
                                    style = MaterialTheme.typography.bodySmall,
                                    textAlign = TextAlign.Center,
                                    color = MaterialTheme.colorScheme.onErrorContainer
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    FilledTonalButton(
                                        onClick = {
                                            val uri = getTempUri()
                                            cameraTempUri = uri
                                            cameraLauncher.launch(uri)
                                        },
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Camera Fallback", fontSize = 12.sp)
                                    }
                                    FilledTonalButton(
                                        onClick = { galleryLauncher.launch("image/*") },
                                        shape = RoundedCornerShape(8.dp)
                                    ) {
                                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Gallery Fallback", fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }

                    // Editable Form Fields
                    EditableIndexForm(
                        result = result,
                        isEditMode = isEditMode || isDbNotFound,
                        onFieldsSaved = { updatedResult ->
                            viewModel.setCurrentScanResult(updatedResult)
                        }
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Global Save & Export controls
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Button(
                            onClick = {
                                viewModel.saveScanResultDirect(result)
                                Toast.makeText(context, "Product saved successfully!", Toast.LENGTH_SHORT).show()
                            },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Save to History", fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = {
                                shareAsCsv(context, result)
                            },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Export CSV", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun borderStroke(color: Color) = androidx.compose.foundation.BorderStroke(1.dp, color)

@Composable
fun SourceIndicatorBanner(source: String) {
    val displaySource = when (source.lowercase()) {
        "upcitemdb" -> "UPCitemdb (Primary Source - Highly Reliable)"
        "open food facts" -> "Open Food Facts (Secondary Fallback)"
        "gemini" -> "Gemini Vision Intelligent VLM"
        "manual" -> "Manual Workspace Entry"
        else -> source
    }

    val bannerColor = when (source.lowercase()) {
        "upcitemdb" -> MaterialTheme.colorScheme.primaryContainer
        "open food facts" -> MaterialTheme.colorScheme.secondaryContainer
        "gemini" -> MaterialTheme.colorScheme.tertiaryContainer
        else -> MaterialTheme.colorScheme.surfaceVariant
    }

    val icon = when (source.lowercase()) {
        "gemini" -> Icons.Default.Build
        "manual" -> Icons.Default.Edit
        else -> Icons.Default.Check
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = bannerColor),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.size(20.dp)
            )
            Text(
                text = "Data Source: $displaySource",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
fun EditableIndexForm(
    result: OcrResultEntity,
    isEditMode: Boolean,
    onFieldsSaved: (OcrResultEntity) -> Unit
) {
    var itemName by remember(result) { mutableStateOf(result.itemName ?: "") }
    var barcode by remember(result) { mutableStateOf(result.barcode ?: "") }
    var manufacturer by remember(result) { mutableStateOf(result.manufacturer ?: "") }
    var brand by remember(result) { mutableStateOf(result.brand ?: "") }
    var weight by remember(result) { mutableStateOf(result.weight ?: "") }
    var packagingType by remember(result) { mutableStateOf(result.packagingType ?: "") }
    var country by remember(result) { mutableStateOf(result.country ?: "") }
    var variant by remember(result) { mutableStateOf(result.variant ?: "") }
    var type by remember(result) { mutableStateOf(result.type ?: "") }
    var fragranceFlavor by remember(result) { mutableStateOf(result.fragranceFlavor ?: "") }
    var promotion by remember(result) { mutableStateOf(result.promotion ?: "") }
    var addons by remember(result) { mutableStateOf(result.addons ?: "") }
    var tagline by remember(result) { mutableStateOf(result.tagline ?: "") }

    // Callback triggers automatically when editing fields
    fun triggerSave() {
        val updated = result.copy(
            itemName = itemName,
            barcode = barcode,
            manufacturer = manufacturer,
            brand = brand,
            weight = weight,
            packagingType = packagingType,
            country = country,
            variant = variant,
            type = type,
            fragranceFlavor = fragranceFlavor,
            promotion = promotion,
            addons = addons,
            tagline = tagline
        )
        onFieldsSaved(updated)
    }

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "13-COLUMN CATALOG MASTER RECORD",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Black,
                color = MaterialTheme.colorScheme.primary
            )

            FormInputField(label = "Item Name", value = itemName, onValueChange = { itemName = it; triggerSave() }, isEditable = isEditMode)
            FormInputField(label = "Barcode Number", value = barcode, onValueChange = { barcode = it; triggerSave() }, isEditable = isEditMode)
            FormInputField(label = "Manufacturer", value = manufacturer, onValueChange = { manufacturer = it; triggerSave() }, isEditable = isEditMode)
            FormInputField(label = "Brand", value = brand, onValueChange = { brand = it; triggerSave() }, isEditable = isEditMode)
            FormInputField(label = "Weight", value = weight, onValueChange = { weight = it; triggerSave() }, isEditable = isEditMode)
            FormInputField(label = "Packaging Type", value = packagingType, onValueChange = { packagingType = it; triggerSave() }, isEditable = isEditMode)
            FormInputField(label = "Country", value = country, onValueChange = { country = it; triggerSave() }, isEditable = isEditMode)
            FormInputField(label = "Variant", value = variant, onValueChange = { variant = it; triggerSave() }, isEditable = isEditMode)
            FormInputField(label = "Type/Category", value = type, onValueChange = { type = it; triggerSave() }, isEditable = isEditMode)
            FormInputField(label = "Fragrance / Flavor", value = fragranceFlavor, onValueChange = { fragranceFlavor = it; triggerSave() }, isEditable = isEditMode)
            FormInputField(label = "Promotion", value = promotion, onValueChange = { promotion = it; triggerSave() }, isEditable = isEditMode)
            FormInputField(label = "Addons", value = addons, onValueChange = { addons = it; triggerSave() }, isEditable = isEditMode)
            FormInputField(label = "Tagline", value = tagline, onValueChange = { tagline = it; triggerSave() }, isEditable = isEditMode)
        }
    }
}

@Composable
fun FormInputField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    isEditable: Boolean
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = label.uppercase(),
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.padding(start = 4.dp, bottom = 4.dp)
        )
        if (isEditable) {
            OutlinedTextField(
                value = value,
                onValueChange = onValueChange,
                singleLine = true,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
                )
            )
        } else {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                    .border(1.dp, MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.12f), RoundedCornerShape(8.dp))
                    .padding(horizontal = 12.dp, vertical = 12.dp)
            ) {
                Text(
                    text = value.ifBlank { "N/A" },
                    style = MaterialTheme.typography.bodyLarge,
                    color = if (value.isBlank()) MaterialTheme.colorScheme.outline else MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}

fun shareAsCsv(context: Context, entity: OcrResultEntity) {
    try {
        val headers = "ITEM_NAME,BARCODE,MANUFACTURER,BRAND,WEIGHT,PACKAGING TYPE,COUNTRY,VARIANT,TYPE,FRAGRANCE_FLAVOR,PROMOTION,ADDONS,TAGLINE"
        fun clean(v: String?) = "\"${v?.replace("\"", "\"\"") ?: ""}\""
        
        val row = "${clean(entity.itemName)},${clean(entity.barcode)},${clean(entity.manufacturer)}," +
                "${clean(entity.brand)},${clean(entity.weight)},${clean(entity.packagingType)}," +
                "${clean(entity.country)},${clean(entity.variant)},${clean(entity.type)}," +
                "${clean(entity.fragranceFlavor)},${clean(entity.promotion)},${clean(entity.addons)}," +
                "${clean(entity.tagline)}"
        
        val csv = "$headers\n$row"
        
        val fileName = "${entity.itemName?.replace("\\s+".toRegex(), "_") ?: "product"}_index.csv"
        val cacheFile = File(context.cacheDir, fileName)
        FileOutputStream(cacheFile).use { out ->
            out.write(csv.toByteArray())
        }
        
        val authority = "${context.packageName}.fileprovider"
        val uri = FileProvider.getUriForFile(context, authority, cacheFile)
        
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"
            putExtra(Intent.EXTRA_SUBJECT, "IMDB Product Export: ${entity.itemName}")
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Export CSV via"))
    } catch (e: Exception) {
        Toast.makeText(context, "Export CSV failed: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}
