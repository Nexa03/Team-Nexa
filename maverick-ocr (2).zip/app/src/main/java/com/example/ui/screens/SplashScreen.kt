package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.ThreeDGearWithFireLogo
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(
    onDismiss: () -> Unit
) {
    var startAnimation by remember { mutableStateOf(false) }

    // Navigation and delay action
    LaunchedEffect(key1 = true) {
        startAnimation = true
        delay(2200) // Show splash for 2.2 seconds
        onDismiss()
    }

    // Fade-in slide-up opening kinematics for the splash canvas
    val animatedOffset by animateDpAsState(
        targetValue = if (startAnimation) 0.dp else 60.dp,
        animationSpec = tween(1000, easing = EaseOutCubic),
        label = "slide_up"
    )
    val animatedAlpha by animateFloatAsState(
        targetValue = if (startAnimation) 1f else 0f,
        animationSpec = tween(1000, easing = LinearOutSlowInEasing),
        label = "fade_in"
    )

    val backgroundGradient = Brush.verticalGradient(
        colors = listOf(
            Color(0xFF1E1E24),
            Color(0xFF121216)
        )
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(backgroundGradient),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .offset(y = animatedOffset)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // HIGH-FIDELITY 3D GEAR WITH REALTIME FIRE
            ThreeDGearWithFireLogo(
                logoSize = 180.dp
            )

            Spacer(modifier = Modifier.height(32.dp))

            // TITLE AND SUBTITLE WITH OPENING ANIMATIONS
            Text(
                text = "MAVERICK OCR",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Black,
                color = Color.White,
                textAlign = TextAlign.Center,
                letterSpacing = 4.sp,
                modifier = Modifier.padding(horizontal = 16.dp)
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "IMAGE-TO-IMDB AUTOMATION ENGINE",
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                textAlign = TextAlign.Center,
                letterSpacing = 2.sp,
                modifier = Modifier.padding(horizontal = 16.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "GDSS Hackathon Maverick 2026",
                style = MaterialTheme.typography.labelSmall,
                color = Color.White.copy(alpha = 0.4f),
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
        }
    }
}
