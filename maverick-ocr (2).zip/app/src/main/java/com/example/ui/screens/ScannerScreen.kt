package com.example.ui.screens

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.hardware.Sensor
import android.hardware.SensorManager
import android.net.Uri
import android.os.SystemClock
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.GraphicsLayerScope
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.local.OcrResultEntity
import com.example.ui.OcrViewModel
import com.example.ui.components.ThreeDGearWithFireLogo
import com.example.util.VoiceSynthesizer
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File
import java.io.InputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.ui.viewinterop.AndroidView
import java.util.concurrent.Executors
import androidx.core.content.ContextCompat
import android.util.Size
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import android.util.Log

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScannerScreen(
    viewModel: OcrViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val clipboardManager = LocalClipboardManager.current

    // Observe ViewModel flows
    val isAnalyzing by viewModel.isAnalyzing.collectAsState()
    val currentResult by viewModel.currentScanResult.collectAsState()
    val scannedUriToConfirm by viewModel.scannedUriToConfirm.collectAsState()
    val errorMessage by viewModel.errorMessage.collectAsState()
    val rawStreak by viewModel.streakCount.collectAsState()
    val configConfirmScan by viewModel.confirmScan.collectAsState()
    val configPreprocessing by viewModel.preprocessing.collectAsState()

    // Screen specific state
    var showTipsSheet by remember { mutableStateOf(false) }
    var showConfetti by remember { mutableStateOf(false) }
    var showProcessedView by remember { mutableStateOf(false) }
    var cameraTempUri by remember { mutableStateOf<Uri?>(null) }
    var isAiVisionMode by remember { mutableStateOf(false) }

    val hasCameraPermission = remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(
                context,
                android.Manifest.permission.CAMERA
            ) == android.content.pm.PackageManager.PERMISSION_GRANTED
        )
    }

    val galleryLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            if (isAiVisionMode) {
                if (configConfirmScan) {
                    viewModel.setupScanForProcessing(uri)
                } else {
                    viewModel.triggerGeminiVisionFallback(uri, null)
                }
            } else {
                viewModel.setupScanForProcessing(uri)
            }
        } else {
            Toast.makeText(context, "Gallery selection cancelled", Toast.LENGTH_SHORT).show()
        }
    }

    // TTS voice synthesis
    val voiceSynthesizer = remember { VoiceSynthesizer(context) }
    DisposableEffect(Unit) {
        onDispose {
            voiceSynthesizer.shutdown()
        }
    }

    // Capture Image temp file generator helper
    fun getTempUri(): Uri {
        val cacheDir = context.cacheDir
        val tempFile = File(cacheDir, "maverick_ocr_capture_${System.currentTimeMillis()}.jpg")
        if (tempFile.exists()) tempFile.delete()
        tempFile.createNewFile()
        val authority = "${context.packageName}.fileprovider"
        return androidx.core.content.FileProvider.getUriForFile(context, authority, tempFile)
    }

    // Camera launcher
    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success ->
        if (success) {
            cameraTempUri?.let { uri ->
                if (isAiVisionMode) {
                    if (configConfirmScan) {
                        viewModel.setupScanForProcessing(uri)
                    } else {
                        viewModel.triggerGeminiVisionFallback(uri, null)
                    }
                } else {
                    viewModel.setupScanForProcessing(uri)
                }
            }
        } else {
            Toast.makeText(context, "Scanning cancelled", Toast.LENGTH_SHORT).show()
        }
    }

    // Shake detector disabled to ensure optimal camera stability and prevent accidental workspace resets.

    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasCameraPermission.value = granted
        if (granted) {
            val fileUri = getTempUri()
            cameraTempUri = fileUri
            cameraLauncher.launch(fileUri)
        } else {
            Toast.makeText(context, "Camera permission is required to operate scanning features.", Toast.LENGTH_LONG).show()
        }
    }

    LaunchedEffect(Unit) {
        if (!hasCameraPermission.value) {
            cameraPermissionLauncher.launch(android.Manifest.permission.CAMERA)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Column {
                            Text(
                                "MAVERICK LABS",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.sp
                            )
                            Text(
                                "Automated Product OCR Pipeline",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }
                    }
                },
                actions = {
                    // Streak count label
                    if (rawStreak > 0) {
                        StreakBadge(rawStreak)
                    }
                    IconButton(onClick = { showTipsSheet = true }) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "Tips Panel",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // CONFETTI LAYER
            if (showConfetti) {
                ConfettiCanvas(
                    onFinished = { showConfetti = false },
                    modifier = Modifier.fillMaxSize()
                )
            }

            // CORE COMPOSITIONS SELECTION
            when {
                errorMessage != null -> {
                    ErrorContent(
                        message = errorMessage ?: "Extraction failed",
                        onRetry = {
                            val fileUri = getTempUri()
                            cameraTempUri = fileUri
                            cameraPermissionLauncher.launch(android.Manifest.permission.CAMERA)
                        },
                        onBack = { viewModel.clearResult() }
                    )
                }
                isAnalyzing -> {
                    ShimmerLoaderContent()
                }
                scannedUriToConfirm != null -> {
                    CaptureReviewContent(
                        imageUri = scannedUriToConfirm!!,
                        onConfirm = {
                            if (isAiVisionMode) {
                                viewModel.triggerGeminiVisionFallback(scannedUriToConfirm!!, null)
                                viewModel.cancelProcessing()
                            } else {
                                viewModel.confirmProcessing()
                            }
                        },
                        onRetake = {
                            viewModel.cancelProcessing()
                            val fileUri = getTempUri()
                            cameraTempUri = fileUri
                            cameraPermissionLauncher.launch(android.Manifest.permission.CAMERA)
                        }
                    )
                }
                else -> {
                    LiveBarcodeScanner(
                        viewModel = viewModel,
                        isAiVisionActive = isAiVisionMode,
                        onModeToggle = { isAiVisionMode = it },
                        hasPermission = hasCameraPermission.value,
                        onRequestPermission = {
                            cameraPermissionLauncher.launch(android.Manifest.permission.CAMERA)
                        },
                        onTriggerGallery = {
                            galleryLauncher.launch("image/*")
                        },
                        onTriggerLegacyCapture = {
                            val fileUri = getTempUri()
                            cameraTempUri = fileUri
                            cameraPermissionLauncher.launch(android.Manifest.permission.CAMERA)
                        }
                    )
                }
            }

            // TIPS BOTTOM SHEET
            if (showTipsSheet) {
                ModalBottomSheet(
                    onDismissRequest = { showTipsSheet = false },
                    sheetState = rememberModalBottomSheetState(),
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = MaterialTheme.colorScheme.onSurface
                ) {
                    TipsSheetContent(onClose = { showTipsSheet = false })
                }
            }
        }
    }
}

// STREAK BADGE FOR SCAN COUNTER
@Composable
fun StreakBadge(days: Int) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val scale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        modifier = Modifier
            .scale(scale)
            .clip(RoundedCornerShape(16.dp))
            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f))
            .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Icon(
            imageVector = Icons.Default.Star,
            contentDescription = "Streak Count",
            tint = Color(0xFFFF8F00),
            modifier = Modifier.size(18.dp)
        )
        Text(
            text = "$days Days",
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )
    }
}

// SCENE 1: COLD WORKSPACE / CAPTURE BUTTON
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun EmptyWorkspaceContent(
    onTriggerScan: () -> Unit,
    onTriggerGallery: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "capture_pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = EaseInOutCubic),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    var showTooltip by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.Top,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Welcome Branding with high visual weight (Dynamic 3D Gear with Glowing Circular Fire)
        ThreeDGearWithFireLogo(
            logoSize = 170.dp,
            modifier = Modifier.padding(vertical = 8.dp)
        )

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = "GDSS MAVERICK",
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Black,
            color = MaterialTheme.colorScheme.primary,
            letterSpacing = 2.sp
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "Automated OCR Extractor",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = "Replace tedious manual entries with our offline-first scanner. Tap the prominent button below to snap a catalog label, food label, or serial number.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 8.dp)
        )

        Spacer(modifier = Modifier.height(36.dp))

        // Futuristic Multi-Input Panel
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f), RoundedCornerShape(20.dp)),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(20.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    "CHOOSE METRIC ENTRY INPUT",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Method 1: Camera
                    ElevatedCard(
                        onClick = onTriggerScan,
                        modifier = Modifier
                            .weight(1f)
                            .height(115.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.elevatedCardColors(
                            containerColor = MaterialTheme.colorScheme.primary
                        )
                    ) {
                        Column(
                            modifier = Modifier.fillMaxSize().padding(8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Add,
                                    contentDescription = "Camera Scan",
                                    tint = MaterialTheme.colorScheme.onPrimary,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Camera", fontWeight = FontWeight.Black, fontSize = 12.sp, color = MaterialTheme.colorScheme.onPrimary)
                            Text("Snap Photo", fontSize = 9.sp, color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.8f))
                        }
                    }

                    // Method 2: Gallery
                    ElevatedCard(
                        onClick = onTriggerGallery,
                        modifier = Modifier
                            .weight(1f)
                            .height(115.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.elevatedCardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                    ) {
                        Column(
                            modifier = Modifier.fillMaxSize().padding(8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Home, // Or standard photos icon
                                    contentDescription = "Gallery Picker",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Gallery", fontWeight = FontWeight.Black, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface)
                            Text("Import Label", fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }

        AnimatedVisibility(
            visible = showTooltip,
            enter = fadeIn() + expandVertically(),
            exit = fadeOut() + shrinkVertically()
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .padding(top = 16.dp)
                    .widthIn(max = 240.dp)
            ) {
                Text(
                    text = "Pro Tip: Long-press shows scanning helper. Center the label completely in standard light and hold solid for supreme accuracy.",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(12.dp),
                    textAlign = TextAlign.Center
                )
            }
        }


    }
}

// SCENE 2: CONFIRM PHOTO CAPTURED PREVIEW SCREEN
@Composable
fun CaptureReviewContent(
    imageUri: Uri,
    onConfirm: () -> Unit,
    onRetake: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.SpaceBetween,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                "Verify Scan Intent",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                "Confirm image layout clarity before processing",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.secondary,
                textAlign = TextAlign.Center
            )
        }

        // Captured Preview Image within a glassmorphic Card container
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(vertical = 24.dp)
                .border(2.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f), RoundedCornerShape(16.dp)),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.8f))
        ) {
            AsyncImage(
                model = imageUri,
                contentDescription = "Captured label raw photo",
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize()
            )
        }

        // Row of confirmation buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            OutlinedButton(
                onClick = onRetake,
                modifier = Modifier
                    .weight(1f)
                    .height(54.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Refresh, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Retake", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            }

            Button(
                onClick = onConfirm,
                modifier = Modifier
                    .weight(1f)
                    .height(54.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Icon(Icons.Default.Check, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Confirm", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
        }
    }
}

// SCENE 3: SHIMMER LOADER FOR BACKGROUND PROCESSING
@Composable
fun ShimmerLoaderContent() {
    val infiniteTransition = rememberInfiniteTransition(label = "shimmer")
    val offset by infiniteTransition.animateFloat(
        initialValue = -300f,
        targetValue = 600f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shimmer_offset"
    )

    val gradient = Brush.linearGradient(
        colors = listOf(
            MaterialTheme.colorScheme.surfaceVariant,
            MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
            MaterialTheme.colorScheme.surfaceVariant
        ),
        start = androidx.compose.ui.geometry.Offset(offset, 0f),
        end = androidx.compose.ui.geometry.Offset(offset + 150f, 0f)
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Visual indicator of OCR running
        CircularProgressIndicator(
            modifier = Modifier.size(60.dp),
            strokeWidth = 5.dp,
            color = MaterialTheme.colorScheme.primary
        )

        Spacer(modifier = Modifier.height(36.dp))

        Text(
            "INTELLIGENTLY RESOLVING",
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Black,
            letterSpacing = 2.sp,
            color = MaterialTheme.colorScheme.primary
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Elegant glass placeholder strips utilizing Shimmer animation
        Box(
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .height(48.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(gradient)
        )

        Spacer(modifier = Modifier.height(12.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth(0.7f)
                .height(24.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(gradient)
        )

        Spacer(modifier = Modifier.height(12.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth(0.8f)
                .height(24.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(gradient)
        )

        Spacer(modifier = Modifier.height(32.dp))

        Text(
            text = "3-Phase Pipeline Active:\n" +
                   "• Phase 1: On-Device Hardware Decoders (100% Offline)\n" +
                   "• Phase 2: Instant SQLite Cache Lookup (0ms Latency)\n" +
                   "• Phase 3: Global Retail Knowledge Lookup (Direct API)",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.outline,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            lineHeight = 20.sp
        )
    }
}

// SCENE 4: COMPLETED RESULTS VIEW (Photo, Details, Count, TTS, Smart Fields, New Scan, Zoom Support, Toggle Processed)
@Composable
fun ResultsContent(
    result: OcrResultEntity,
    showProcessedView: Boolean,
    onToggleProcessed: () -> Unit,
    onCopyText: () -> Unit,
    onPlayVoice: () -> Unit,
    onNewScan: () -> Unit,
    onUpdateResult: (OcrResultEntity) -> Unit,
    mergeSuggestions: List<OcrResultEntity> = emptyList()
) {
    val localContext = LocalContext.current
    var rawTextExpanded by remember { mutableStateOf(false) }

    // Editable states for the 13 central IMDB attributes
    var nameState by remember(result) { mutableStateOf(result.itemName ?: "") }
    var barcodeState by remember(result) { mutableStateOf(result.barcode ?: "") }
    var manufacturerState by remember(result) { mutableStateOf(result.manufacturer ?: "") }
    var brandState by remember(result) { mutableStateOf(result.brand ?: "") }
    var weightState by remember(result) { mutableStateOf(result.weight ?: "") }
    var packagingState by remember(result) { mutableStateOf(result.packagingType ?: "") }
    var countryState by remember(result) { mutableStateOf(result.country ?: "") }
    var variantState by remember(result) { mutableStateOf(result.variant ?: "") }
    var typeState by remember(result) { mutableStateOf(result.type ?: "") }
    var fragranceFlavorState by remember(result) { mutableStateOf(result.fragranceFlavor ?: "") }
    var promoState by remember(result) { mutableStateOf(result.promotion ?: "") }
    var addonsState by remember(result) { mutableStateOf(result.addons ?: "") }
    var taglineState by remember(result) { mutableStateOf(result.tagline ?: "") }

    // Multi-touch Zoom states for image
    var scale by remember { mutableStateOf(1f) }
    var offsetState by remember { mutableStateOf(androidx.compose.ui.geometry.Offset.Zero) }
    val state = rememberTransformableState { zoomChange, offsetChange, _ ->
        scale = (scale * zoomChange).coerceIn(1f, 3f)
        offsetState += offsetChange
    }

    // Toggle Animations (Scale & Rotate)
    val processedRotationState by animateFloatAsState(
        targetValue = if (showProcessedView) 360f else 0f,
        animationSpec = tween(400, easing = EaseInOutSine),
        label = "rotation"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Success Motivation Header - Bold Typography Design Theme Style
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Bottom
        ) {
            Column {
                Text(
                    text = "SCAN RESULT",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.5.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "PRODUCT\nDETAILS",
                    style = MaterialTheme.typography.headlineLarge,
                    fontWeight = FontWeight.Black,
                    lineHeight = 28.sp
                )
            }
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(Color.White)
                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f), CircleShape)
                    .clickable { onPlayVoice() },
                contentAlignment = Alignment.Center
            ) {
                Text("ⓘ", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            }
        }

        // Images display container with optional pinch-to-zoom and contrast processed switch
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(240.dp)
                .border(
                    width = 1.dp,
                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(16.dp)
                ),
            shape = RoundedCornerShape(16.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black)
                    .clip(RoundedCornerShape(16.dp))
                    .transformable(state = state)
            ) {
                val imageToLoad = if (showProcessedView && result.processedImageUri != null) {
                    result.processedImageUri
                } else {
                    result.imageUri
                }

                if (imageToLoad.isNullOrBlank()) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.linearGradient(
                                    colors = listOf(
                                        Color(0xFF0D1B2A),
                                        Color(0xFF1B263B),
                                        Color(0xFF415A77)
                                    )
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = "█║▌│█│║▌║║│║▌║█║▌║",
                                style = MaterialTheme.typography.headlineLarge,
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.85f),
                                letterSpacing = 2.sp,
                                fontWeight = FontWeight.Black
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = result.barcode ?: "000000000000",
                                style = MaterialTheme.typography.titleLarge,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "DIGITALLY RESOLVED VIA GLOBAL REGISTRY",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.sp
                            )
                        }
                    }
                } else {
                    AsyncImage(
                        model = imageToLoad,
                        contentDescription = "Extracted label result photo",
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer(
                                scaleX = scale,
                                scaleY = scale,
                                translationX = offsetState.x,
                                translationY = offsetState.y
                            )
                    )
                }

                // Glass overlay badges
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(12.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.Black.copy(alpha = 0.6f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = if (showProcessedView) "PREPROCESSED VIEW" else "RAW CAMERA IMAGE",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White
                    )
                }

                // Confidence indicator badge
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(12.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(
                            when (result.confidence) {
                                "High" -> Color(0xFF2E7D32)
                                "Medium" -> Color(0xFFEF6C00)
                                else -> Color(0xFFC62828)
                            }.copy(alpha = 0.85f)
                        )
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "Confidence: ${result.confidence}",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Processed Image View Toggle Controls (Feature 5)
        if (result.processedImageUri != null) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                    .clickable { onToggleProcessed() }
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.rotate(processedRotationState)
                    )
                    Column {
                        Text(
                            text = "Toggle Processed View",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Grayscale & amplified contrast versions",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.outline
                        )
                    }
                }
                Switch(
                    checked = showProcessedView,
                    onCheckedChange = { onToggleProcessed() }
                )
            }
        }

        // Metrics display card (Characters, words, Voice TTS button)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            MetricCard(
                title = "Total Characters",
                value = result.charCount,
                modifier = Modifier.weight(1f)
            )
            MetricCard(
                title = "Words Extracted",
                value = result.wordCount,
                modifier = Modifier.weight(1f)
            )

            // Voice announcement microphone button
            Card(
                modifier = Modifier
                    .size(68.dp)
                    .clickable { onPlayVoice() }
                    .border(
                        1.dp,
                        MaterialTheme.colorScheme.primary.copy(alpha = 0.2f),
                        RoundedCornerShape(12.dp)
                    ),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Voice Summary",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(32.dp)
                    )
                }
            }
        }

        // Duplicate Merge Suggestions alert panel
        if (mergeSuggestions.isNotEmpty()) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.6f), RoundedCornerShape(12.dp)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.15f))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                        Text(
                            "Merge Conflict Alert",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Black,
                            color = MaterialTheme.colorScheme.error
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        "We detected ${mergeSuggestions.size} duplicate record(s) matching brand & weight or barcode in your master database. Double-check to avoid duplicate entries.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    mergeSuggestions.forEach { duplicate ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.background.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(duplicate.itemName ?: "Unnamed", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                                Text("Barcode: ${duplicate.barcode ?: "-"} | Brand: ${duplicate.brand ?: "-"} | Weight: ${duplicate.weight ?: "-"}", style = MaterialTheme.typography.bodySmall, fontSize = 10.sp, color = MaterialTheme.colorScheme.outline)
                            }
                            TextButton(onClick = {
                                barcodeState = duplicate.barcode ?: ""
                                nameState = duplicate.itemName ?: ""
                                manufacturerState = duplicate.manufacturer ?: ""
                                brandState = duplicate.brand ?: ""
                                weightState = duplicate.weight ?: ""
                                packagingState = duplicate.packagingType ?: ""
                                countryState = duplicate.country ?: ""
                                variantState = duplicate.variant ?: ""
                                typeState = duplicate.type ?: ""
                                fragranceFlavorState = duplicate.fragranceFlavor ?: ""
                                promoState = duplicate.promotion ?: ""
                                addonsState = duplicate.addons ?: ""
                                taglineState = duplicate.tagline ?: ""
                                Toast.makeText(localContext, "Loaded values from duplicate entry!", Toast.LENGTH_SHORT).show()
                            }) {
                                Text("Copy Values", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // Low Confidence Indicator Alert
        if (result.lowConfidenceFlag) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFFFFF3E0), RoundedCornerShape(12.dp))
                    .border(1.dp, Color(0xFFFFB74D), RoundedCornerShape(12.dp))
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("⚠️", fontSize = 20.sp)
                Column {
                    Text(
                        text = "MANUAL REVIEW RECOMMENDED",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFE65100)
                    )
                    Text(
                        text = "The system auto-generated placeholder barcodes or name details. Please correct them below for database consistency.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF5D4037)
                    )
                }
            }
        }

        // 10 IMDB ATTRIBUTES EDIT CONTAINER
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f), RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Text(
                    text = "ITEM MASTER DATABASE (IMDB) FIELDS",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Black,
                    color = MaterialTheme.colorScheme.primary,
                    letterSpacing = 1.sp
                )

                // Field 1: Item Name
                OutlinedTextField(
                    value = nameState,
                    onValueChange = { nameState = it },
                    label = { Text("1. Item Name (Descriptive Catalog Name)") },
                    leadingIcon = { Icon(Icons.Default.Info, contentDescription = null, modifier = Modifier.size(20.dp)) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                // Field 2: Barcode
                OutlinedTextField(
                    value = barcodeState,
                    onValueChange = { barcodeState = it },
                    label = { Text("2. Barcode (UPC / EAN)") },
                    leadingIcon = { Icon(Icons.Default.Build, contentDescription = null, modifier = Modifier.size(20.dp)) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                // Field 3: Manufacturer
                OutlinedTextField(
                    value = manufacturerState,
                    onValueChange = { manufacturerState = it },
                    label = { Text("3. Manufacturer") },
                    leadingIcon = { Icon(Icons.Default.Home, contentDescription = null, modifier = Modifier.size(20.dp)) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                // Field 4: Brand name
                OutlinedTextField(
                    value = brandState,
                    onValueChange = { brandState = it },
                    label = { Text("4. Brand Name") },
                    leadingIcon = { Icon(Icons.Default.Star, contentDescription = null, modifier = Modifier.size(20.dp)) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                // Field 5: Weight
                OutlinedTextField(
                    value = weightState,
                    onValueChange = { weightState = it },
                    label = { Text("5. Weight & Size (e.g., 500g, 430ML)") },
                    placeholder = { Text("e.g., 500g, 1L, 1.5 lbs, 250ml") },
                    leadingIcon = { Icon(Icons.Default.ShoppingCart, contentDescription = null, modifier = Modifier.size(20.dp)) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                // Field 6: Packaging Type
                OutlinedTextField(
                    value = packagingState,
                    onValueChange = { packagingState = it },
                    label = { Text("6. Packaging Type") },
                    placeholder = { Text("TUB, GLASS JAR, SACHET, BOTTLE, CAN etc.") },
                    leadingIcon = { Icon(Icons.Default.Build, contentDescription = null, modifier = Modifier.size(20.dp)) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                // Field 7: Country
                OutlinedTextField(
                    value = countryState,
                    onValueChange = { countryState = it },
                    label = { Text("7. Country of Origin") },
                    leadingIcon = { Icon(Icons.Default.Place, contentDescription = null, modifier = Modifier.size(20.dp)) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                // Field 8: Variant
                OutlinedTextField(
                    value = variantState,
                    onValueChange = { variantState = it },
                    label = { Text("8. Variant (e.g., ORIGINAL, CHILLI)") },
                    leadingIcon = { Icon(Icons.Default.Face, contentDescription = null, modifier = Modifier.size(20.dp)) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                // Field 9: Type / Category
                OutlinedTextField(
                    value = typeState,
                    onValueChange = { typeState = it },
                    label = { Text("9. Product Type (e.g., MARGARINE, MAYONNAISE)") },
                    leadingIcon = { Icon(Icons.Default.Menu, contentDescription = null, modifier = Modifier.size(20.dp)) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                // Field 10: Fragrance / Flavor
                OutlinedTextField(
                    value = fragranceFlavorState,
                    onValueChange = { fragranceFlavorState = it },
                    label = { Text("10. Fragrance / Flavor") },
                    leadingIcon = { Icon(Icons.Default.Favorite, contentDescription = null, modifier = Modifier.size(20.dp)) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                // Field 11: Promotion
                OutlinedTextField(
                    value = promoState,
                    onValueChange = { promoState = it },
                    label = { Text("11. Promotion (e.g., 10% EXTRA)") },
                    leadingIcon = { Icon(Icons.Default.Favorite, contentDescription = null, modifier = Modifier.size(20.dp)) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                // Field 12: Addons
                OutlinedTextField(
                    value = addonsState,
                    onValueChange = { addonsState = it },
                    label = { Text("12. Addons") },
                    leadingIcon = { Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(20.dp)) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                // Field 13: Tagline
                OutlinedTextField(
                    value = taglineState,
                    onValueChange = { taglineState = it },
                    label = { Text("13. Tagline") },
                    leadingIcon = { Icon(Icons.Default.MailOutline, contentDescription = null, modifier = Modifier.size(20.dp)) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                // Actions Column
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Normalize standard taxonomy fields
                    OutlinedButton(
                        onClick = {
                            brandState = com.example.util.ImdbNormalizer.standardizeBrand(brandState)
                            typeState = com.example.util.ImdbNormalizer.standardizeCategory(typeState)
                            variantState = com.example.util.ImdbNormalizer.standardizeSegment(variantState)
                            packagingState = com.example.util.ImdbNormalizer.standardizePackaging(packagingState)
                            countryState = com.example.util.ImdbNormalizer.standardizeCountry(countryState)
                            Toast.makeText(localContext, "Applied dynamic normalization criteria!", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Standardize", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }

                    // Save updates directly to history database
                    Button(
                        onClick = {
                            val isStillGenerated = barcodeState.startsWith("BAR-NEW-")
                            val isStillUnknownName = nameState == "Standard Product Item"
                            val isStillUnknownBrand = brandState == "Unknown Brand"
                            val nowLowConfidence = isStillGenerated || isStillUnknownName || isStillUnknownBrand

                            val updated = result.copy(
                                itemName = nameState,
                                barcode = barcodeState,
                                manufacturer = manufacturerState,
                                brand = brandState,
                                weight = weightState,
                                packagingType = packagingState,
                                country = countryState,
                                variant = variantState,
                                type = typeState,
                                fragranceFlavor = fragranceFlavorState,
                                promotion = promoState,
                                addons = addonsState,
                                tagline = taglineState,
                                lowConfidenceFlag = nowLowConfidence,
                                standardizedFlag = true
                            )
                            onUpdateResult(updated)
                            Toast.makeText(localContext, "Successfully updated IMDB product row in central catalog!", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Save Changes", fontWeight = FontWeight.Black, fontSize = 12.sp)
                    }
                }
            }
        }

        // Export Row to CSV spreadsheet specifically for this scanned item
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(2.dp, Color.White, RoundedCornerShape(20.dp)),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.12f))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Export Product Row", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                    Text("Share single-row CSV for instant excel imports", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton(
                    onClick = {
                        val entity = result.copy(
                            itemName = nameState,
                            barcode = barcodeState,
                            manufacturer = manufacturerState,
                            brand = brandState,
                            weight = weightState,
                            packagingType = packagingState,
                            country = countryState,
                            variant = variantState,
                            type = typeState,
                            fragranceFlavor = fragranceFlavorState,
                            promotion = promoState,
                            addons = addonsState,
                            tagline = taglineState
                        )
                        com.example.ui.screens.exportHistory(localContext, listOf(entity), asJson = false)
                    },
                    colors = IconButtonDefaults.iconButtonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Icon(Icons.Default.Share, contentDescription = "Export product CSV row", tint = Color.White)
                }
            }
        }

        // Extracted RAW Text Card with expandable "Show More" option (Glassmorphic look)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .border(
                    width = 2.dp,
                    color = Color.White.copy(alpha = 0.9f),
                    shape = RoundedCornerShape(24.dp)
                ),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f))
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "RECONSTRUCTED LABEL TRANSCRIPT",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.8f),
                        letterSpacing = 1.sp
                    )

                    // Custom styled timezone date stamp e.g. "12:44 PM • FEB 24"
                    val format = remember { SimpleDateFormat("h:mm a • MMM d", Locale.US) }
                    Box(
                        modifier = Modifier
                            .background(
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
                                shape = RoundedCornerShape(6.dp)
                            )
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = format.format(Date(result.timestamp)).uppercase(),
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                val truncatedText = if (result.rawText.length > 280 && !rawTextExpanded) {
                    result.rawText.take(280) + "..."
                } else {
                    result.rawText
                }

                Text(
                    text = truncatedText,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 13.sp,
                    lineHeight = 18.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                            RoundedCornerShape(8.dp)
                        )
                        .padding(12.dp)
                )

                if (result.rawText.length > 280) {
                    TextButton(
                        onClick = { rawTextExpanded = !rawTextExpanded },
                        modifier = Modifier
                            .align(Alignment.End)
                            .padding(top = 4.dp)
                    ) {
                        Text(
                            text = if (rawTextExpanded) "Show Less" else "Show More",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        }

        // Actions Row (Copy, Repeat camera)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            OutlinedButton(
                onClick = onCopyText,
                modifier = Modifier
                    .weight(1f)
                    .height(54.dp),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Send, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Copy Text", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            }

            Button(
                onClick = onNewScan,
                modifier = Modifier
                    .weight(1f)
                    .height(54.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Icon(Icons.Default.Create, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("New Scan", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(110.dp)) // Extra layout padding for navigation spacing in adaptive viewport
    }
}

// METRICS CARD WITH COUNTER ANIMATION EFFECT
@Composable
fun MetricCard(
    title: String,
    value: Int,
    modifier: Modifier = Modifier
) {
    val animatedValue by animateIntAsState(
        targetValue = value,
        animationSpec = tween(1200, easing = EaseOutCubic),
        label = "count"
    )

    Card(
        modifier = modifier.border(
            width = 1.dp,
            color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f),
            shape = RoundedCornerShape(12.dp)
        ),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.Start
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.outline
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "$animatedValue",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Black,
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}

// SMART RECOGNITION HIGHLIGHT FIELD ELEMENT
@Composable
fun SmartFieldChip(
    label: String,
    value: String,
    color: Color
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(color.copy(alpha = 0.08f))
            .border(1.dp, color.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
            .padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Black,
            color = color,
            letterSpacing = 1.sp
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}

// SCENE 5: ERROR CONTENT VIEW (e.g. No text extracted)
@Composable
fun ErrorContent(
    message: String,
    onRetry: () -> Unit,
    onBack: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(100.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.error.copy(alpha = 0.1f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Warning,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.error,
                modifier = Modifier.size(48.dp)
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = "EVALUATION EXCEPTION",
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Black,
            color = MaterialTheme.colorScheme.error,
            letterSpacing = 1.5.sp
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "Extraction Blank",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = message,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 16.dp)
        )

        Spacer(modifier = Modifier.height(36.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            OutlinedButton(
                onClick = onBack,
                modifier = Modifier
                    .weight(1f)
                    .height(50.dp)
            ) {
                Text("Back to Home")
            }

            Button(
                onClick = onRetry,
                modifier = Modifier
                    .weight(1f)
                    .height(50.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
            ) {
                Text("Scan Again")
            }
        }
    }
}

// USER TIPS SHEET CONTENTS
@Composable
fun TipsSheetContent(
    onClose: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "Tips for Best Results",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Black
        )

        HorizontalDivider()

        TipItem(
            icon = Icons.Default.Check,
            title = "Place label on flat surface",
            description = "Hold product solid. Curve surfaces are harder to parse correctly. Smooth flat planes yield higher confidence parameters."
        )

        TipItem(
            icon = Icons.Default.CheckCircle,
            title = "Ensure high contrast contrast light",
            description = "Avoid dark environments. The optional preprocessor dynamically scales contrast, but solid initial light delivers clean inputs."
        )

        TipItem(
            icon = Icons.Default.Search,
            title = "Capture entire label bounding box",
            description = "Let ML SDK auto align. Capture the whole label layout rather than tiny segments for price structure parsing to match accurately."
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = onClose,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Got it")
        }
    }
}

@Composable
fun TipItem(
    icon: ImageVector,
    title: String,
    description: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(20.dp)
            )
        }

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = description,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

// REALTIME CANVAS CONFETTI EFFECT (COMPLETELY OFFLINE & STANDALONE)
@Composable
fun ConfettiCanvas(
    onFinished: () -> Unit,
    modifier: Modifier = Modifier
) {
    val duration = 2500
    val particles = remember {
        List(110) {
            ConfettiParticle(
                x = Random.nextFloat(),
                y = -0.1f - Random.nextFloat() * 0.4f,
                speed = 2f + Random.nextFloat() * 5f,
                angle = Random.nextFloat() * 360f,
                color = Color(
                    red = Random.nextInt(256),
                    green = Random.nextInt(256),
                    blue = Random.nextInt(256)
                ),
                rotationSpeed = Random.nextFloat() * 10f,
                size = 12f + Random.nextFloat() * 20f
            )
        }
    }

    val animTime = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        animTime.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = duration, easing = LinearEasing)
        )
        onFinished()
    }

    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val t = animTime.value

        particles.forEach { p ->
            val particleY = p.y * h + (t * duration * 0.25f * p.speed)
            val particleX = (p.x * w) + (kotlin.math.sin(t * 8f + p.angle) * 35f)
            val currentRot = p.angle + (t * 360f * p.rotationSpeed)

            if (particleY in 0f..h) {
                rotate(degrees = currentRot, pivot = androidx.compose.ui.geometry.Offset(particleX, particleY)) {
                    drawRect(
                        color = p.color,
                        topLeft = androidx.compose.ui.geometry.Offset(particleX - p.size / 2, particleY - p.size / 2),
                        size = androidx.compose.ui.geometry.Size(p.size, p.size / 1.5f)
                    )
                }
            }
        }
    }
}

data class ConfettiParticle(
    val x: Float,
    val y: Float,
    val speed: Float,
    val angle: Float,
    val color: Color,
    val rotationSpeed: Float,
    val size: Float
)

@Composable
fun LiveBarcodeScanner(
    viewModel: OcrViewModel,
    isAiVisionActive: Boolean,
    onModeToggle: (Boolean) -> Unit,
    hasPermission: Boolean,
    onRequestPermission: () -> Unit,
    onTriggerGallery: () -> Unit,
    onTriggerLegacyCapture: () -> Unit,
    modifier: Modifier = Modifier
) {
    if (!hasPermission) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            ElevatedCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.elevatedCardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                )
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(18.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Send,
                        contentDescription = "Upload Asset Indicator",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier
                            .size(56.dp)
                            .background(
                                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                                shape = CircleShape
                            )
                            .padding(12.dp)
                    )

                    Text(
                        text = "Maverick Scan Center",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Text(
                        text = "Select your identification mode below, then upload an image from your device gallery to analyze instantly.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )

                    // Mode Selection for offline analysis
                    ScanModeToggle(
                        isSelectedAi = isAiVisionActive,
                        onModeChange = onModeToggle,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )

                    // Large, dedicated, high-fidelity premium upload container
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f))
                            .clickable { onTriggerGallery() }
                            .border(
                                width = 1.5.dp,
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.6f),
                                shape = RoundedCornerShape(16.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Send,
                                contentDescription = "Select files",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(28.dp)
                            )
                            Text(
                                text = if (isAiVisionActive) "Upload & Identify Picture" else "Upload & Decode Barcode",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "JPEG, PNG, WEBP • Up to 10MB",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    // Divider segment
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(modifier = Modifier.weight(1f).height(1.dp).background(MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.2f)))
                        Text(
                            text = "OR",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                            modifier = Modifier.padding(horizontal = 12.dp)
                        )
                        Box(modifier = Modifier.weight(1f).height(1.dp).background(MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.2f)))
                    }

                    // Request real-time camera mode option
                    Button(
                        onClick = onRequestPermission,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(imageVector = Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp))
                            Text("Unlock Live Camera Guide", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
        return
    }

    val context = LocalContext.current
    val lifecycleOwner = androidx.compose.ui.platform.LocalLifecycleOwner.current
    val executor = remember { Executors.newSingleThreadExecutor() }

    DisposableEffect(Unit) {
        onDispose {
            executor.shutdown()
        }
    }

    var statusText by remember { mutableStateOf("Keep scanning...") }
    var scanDurationSeconds by remember { mutableStateOf(0) }
    var isProcessed by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            scanDurationSeconds++
            statusText = when {
                scanDurationSeconds < 2 -> "Keep scanning..."
                scanDurationSeconds in 2..4 -> "Align barcode center-frame"
                else -> "Point camera at barcode (try adjusting distance/lighting)"
            }
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
        AndroidView(
            factory = { ctx ->
                val previewView = PreviewView(ctx).apply {
                    scaleType = PreviewView.ScaleType.FILL_CENTER
                }

                val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                cameraProviderFuture.addListener({
                    try {
                        val cameraProvider = cameraProviderFuture.get()

                        val preview = Preview.Builder().build().apply {
                            setSurfaceProvider(previewView.surfaceProvider)
                        }

                        val imageAnalysis = ImageAnalysis.Builder()
                            .setTargetResolution(Size(1280, 720))
                            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                            .build()

                        val options = BarcodeScannerOptions.Builder()
                            .setBarcodeFormats(Barcode.FORMAT_ALL_FORMATS)
                            .build()
                        val scanner = BarcodeScanning.getClient(options)

                        imageAnalysis.setAnalyzer(executor) { imageProxy ->
                            val mediaImage = imageProxy.image
                            if (mediaImage != null && !isProcessed && !isAiVisionActive) {
                                val inputImage = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
                                scanner.process(inputImage)
                                    .addOnSuccessListener { barcodes ->
                                        val barcode = barcodes.firstOrNull()
                                        if (barcode != null && !isProcessed) {
                                            val value = barcode.rawValue ?: barcode.displayValue
                                            if (value != null) {
                                                isProcessed = true
                                                try {
                                                    val vibrator = ctx.getSystemService(Context.VIBRATOR_SERVICE) as? android.os.Vibrator
                                                    vibrator?.let {
                                                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                                                            it.vibrate(android.os.VibrationEffect.createOneShot(120, android.os.VibrationEffect.DEFAULT_AMPLITUDE))
                                                        } else {
                                                            it.vibrate(120)
                                                        }
                                                    }
                                                } catch (ex: Exception) {}

                                                viewModel.triggerBarcodeLookup(value)
                                            }
                                        }
                                    }
                                    .addOnCompleteListener {
                                        imageProxy.close()
                                    }
                            } else {
                                imageProxy.close()
                            }
                        }

                        val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
                        cameraProvider.unbindAll()
                        cameraProvider.bindToLifecycle(
                            lifecycleOwner,
                            cameraSelector,
                            preview,
                            imageAnalysis
                        )
                    } catch (e: Exception) {
                        Log.e("LiveBarcodeScanner", "Failed to bind CameraX Lifecycle: ${e.message}")
                    }
                }, ContextCompat.getMainExecutor(ctx))

                previewView
            },
            modifier = Modifier.fillMaxSize()
        )

        // Floating premium scan mode selector
        Row(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 24.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.Center
        ) {
            ScanModeToggle(
                isSelectedAi = isAiVisionActive,
                onModeChange = onModeToggle
            )
        }

        // Holographic corner bracket scan overlay or AI target ring
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            if (isAiVisionActive) {
                // Circular Target Focal ring for AI vision matching
                val infiniteTransition = rememberInfiniteTransition(label = "pulse")
                val scaleFactor by infiniteTransition.animateFloat(
                    initialValue = 0.95f,
                    targetValue = 1.05f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(1200, easing = EaseInOutSine),
                        repeatMode = RepeatMode.Reverse
                    ),
                    label = "scale_factor"
                )
                Box(
                    modifier = Modifier
                        .size(240.dp)
                        .scale(scaleFactor)
                        .border(
                            width = 3.dp,
                            brush = Brush.radialGradient(
                                colors = listOf(
                                    MaterialTheme.colorScheme.primary,
                                    MaterialTheme.colorScheme.secondary
                                )
                            ),
                            shape = CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    // Small inner target dot
                    Box(
                        modifier = Modifier
                            .size(12.dp)
                            .background(MaterialTheme.colorScheme.primary, CircleShape)
                    )
                }
            } else {
                Box(
                    modifier = Modifier
                        .size(240.dp)
                        .border(2.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                ) {
                    val infiniteTransition = rememberInfiniteTransition(label = "laser")
                    val laserOffset by infiniteTransition.animateFloat(
                        initialValue = 0.1f,
                        targetValue = 0.9f,
                        animationSpec = infiniteRepeatable(
                            animation = tween(1500, easing = EaseInOutSine),
                            repeatMode = RepeatMode.Reverse
                        ),
                        label = "laser_offset"
                    )

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .fillMaxHeight(0.006f)
                            .align(Alignment.TopCenter)
                            .graphicsLayer {
                                translationY = laserOffset * 240.dp.toPx()
                            }
                            .background(
                                Brush.horizontalGradient(
                                    colors = listOf(
                                        Color.Transparent,
                                        MaterialTheme.colorScheme.primary,
                                        Color.Transparent
                                    )
                                )
                            )
                    )
                }
            }
        }

        // Live Scanning HUD
        Card(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 100.dp, start = 24.dp, end = 24.dp)
                .fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.88f))
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                CircularProgressIndicator(
                    modifier = Modifier.size(24.dp),
                    strokeWidth = 2.5.dp,
                    color = MaterialTheme.colorScheme.primary
                )
                Column {
                    Text(
                        text = if (isAiVisionActive) "AI VISION IDENTIFIER" else "LIVE RETAIL SCANNER",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = if (isAiVisionActive) "Align product in target circle & snap to identify" else statusText,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Action panel controls
        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 32.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Upload Image Selector Access
            Button(
                onClick = onTriggerGallery,
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.95f),
                    contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.height(48.dp)
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Send,
                        contentDescription = "Upload Image Icon",
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "Upload Image",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 13.sp,
                        letterSpacing = 0.5.sp
                    )
                }
            }

            // Legacy manual Photo capture
            Button(
                onClick = onTriggerLegacyCapture,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isAiVisionActive) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.primary
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.height(48.dp)
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (isAiVisionActive) Icons.Default.Star else Icons.Default.Search,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = if (isAiVisionActive) "Identify Picture" else "Snap Photo",
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 13.sp,
                        letterSpacing = 0.5.sp
                    )
                }
            }
        }
    }
}

@Composable
fun ScanModeToggle(
    isSelectedAi: Boolean,
    onModeChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.85f))
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val selectedColor = MaterialTheme.colorScheme.primary
        val onSelectedColor = MaterialTheme.colorScheme.onPrimary
        val unselectedColor = Color.Transparent
        val onUnselectedColor = MaterialTheme.colorScheme.onSurfaceVariant

        // Barcode Mode Option
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(16.dp))
                .background(if (!isSelectedAi) selectedColor else unselectedColor)
                .clickable { onModeChange(false) }
                .padding(horizontal = 16.dp, vertical = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = null,
                    tint = if (!isSelectedAi) onSelectedColor else onUnselectedColor,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = "Barcode Scan",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = if (!isSelectedAi) onSelectedColor else onUnselectedColor
                )
            }
        }

        // AI Vision Mode Option
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(16.dp))
                .background(if (isSelectedAi) selectedColor else unselectedColor)
                .clickable { onModeChange(true) }
                .padding(horizontal = 16.dp, vertical = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Star,
                    contentDescription = null,
                    tint = if (isSelectedAi) onSelectedColor else onUnselectedColor,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = "AI Picture Identifier",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold,
                    color = if (isSelectedAi) onSelectedColor else onUnselectedColor
                )
            }
        }
    }
}
