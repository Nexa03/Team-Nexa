package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.local.OcrResultEntity
import com.example.ui.OcrViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HistoryScreen(
    viewModel: OcrViewModel,
    onNavigateToTab: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val history by viewModel.allHistory.collectAsState()

    // Multi-select state
    var isMultiSelectActive by remember { mutableStateOf(false) }
    val selectedItems = remember { mutableStateListOf<OcrResultEntity>() }

    // Filter states
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategoryFilter by remember { mutableStateOf<String?>(null) }
    var selectedBrandFilter by remember { mutableStateOf<String?>(null) }
    var selectedPackagingFilter by remember { mutableStateOf<String?>(null) }
    var showReviewOnly by remember { mutableStateOf(false) }

    // Extracted dynamic filters from database
    val availableCategories = remember(history) {
        history.mapNotNull { it.type }.filter { it.isNotBlank() }.distinct().sorted()
    }
    val availableBrands = remember(history) {
        history.mapNotNull { it.brand }.filter { it.isNotBlank() }.distinct().sorted()
    }
    val availablePackaging = remember(history) {
        history.mapNotNull { it.packagingType }.filter { it.isNotBlank() }.distinct().sorted()
    }

    // Filter history reactively
    val filteredHistory = remember(history, searchQuery, selectedCategoryFilter, selectedBrandFilter, selectedPackagingFilter, showReviewOnly) {
        history.filter { item ->
            val matchesSearch = searchQuery.isBlank() || 
                (item.itemName ?: "").contains(searchQuery, ignoreCase = true) ||
                (item.brand ?: "").contains(searchQuery, ignoreCase = true) ||
                (item.barcode ?: "").contains(searchQuery, ignoreCase = true) ||
                (item.manufacturer ?: "").contains(searchQuery, ignoreCase = true) ||
                (item.rawText ?: "").contains(searchQuery, ignoreCase = true)

            val matchesCategory = selectedCategoryFilter == null || item.type == selectedCategoryFilter
            val matchesBrand = selectedBrandFilter == null || item.brand == selectedBrandFilter
            val matchesPackaging = selectedPackagingFilter == null || item.packagingType == selectedPackagingFilter
            val matchesReview = !showReviewOnly || item.lowConfidenceFlag == true

            matchesSearch && matchesCategory && matchesBrand && matchesPackaging && matchesReview
        }
    }

    // Clear state on count change
    LaunchedEffect(history.size) {
        if (history.isEmpty()) {
            isMultiSelectActive = false
            selectedItems.clear()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "CENTRAL MASTER INDEX",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.5.sp
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = if (isMultiSelectActive) "${selectedItems.size} SELECTED" else "IMDB CATALOG",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Black
                        )
                    }
                },
                actions = {
                    if (isMultiSelectActive) {
                        IconButton(onClick = {
                            viewModel.deleteSelectedItems(selectedItems)
                            isMultiSelectActive = false
                            selectedItems.clear()
                            Toast.makeText(context, "Deleted selected items!", Toast.LENGTH_SHORT).show()
                        }) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Delete Selected",
                                tint = MaterialTheme.colorScheme.error
                            )
                        }
                        IconButton(onClick = {
                            isMultiSelectActive = false
                            selectedItems.clear()
                        }) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Cancel Multi-select"
                            )
                        }
                    } else if (filteredHistory.isNotEmpty()) {
                        // Export Excel/CSV Menu
                        var showMenu by remember { mutableStateOf(false) }
                        Box {
                            IconButton(onClick = { showMenu = true }) {
                                Icon(
                                    imageVector = Icons.Default.Share,
                                    contentDescription = "Export History Options",
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                            DropdownMenu(
                                expanded = showMenu,
                                onDismissRequest = { showMenu = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text("Export Filtered to CSV Spreadsheet") },
                                    leadingIcon = { Icon(Icons.Default.List, contentDescription = null) },
                                    onClick = {
                                        showMenu = false
                                        exportHistory(context, filteredHistory, asJson = false)
                                    }
                                )
                                DropdownMenuItem(
                                    text = { Text("Export Filtered to JSON Master") },
                                    leadingIcon = { Icon(Icons.Default.Build, contentDescription = null) },
                                    onClick = {
                                        showMenu = false
                                        exportHistory(context, filteredHistory, asJson = true)
                                    }
                                )
                            }
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (history.isEmpty()) {
                EmptyHistoryView()
            } else {
                Column(modifier = Modifier.fillMaxSize()) {
                    // Search and Filter controls bar
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Outlined Search field
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = { searchQuery = it },
                            placeholder = { Text("Search catalog by name, brand, or barcode...") },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                            trailingIcon = {
                                if (searchQuery.isNotEmpty()) {
                                    IconButton(onClick = { searchQuery = "" }) {
                                        Icon(Icons.Default.Clear, contentDescription = "Clear search")
                                    }
                                }
                            },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        )

                        // Scrollable filter chips Row
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Review status quick filter
                            FilterChip(
                                selected = showReviewOnly,
                                onClick = { showReviewOnly = !showReviewOnly },
                                label = { Text("⚠️ Needs Review") },
                                leadingIcon = if (showReviewOnly) {
                                    { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                                } else null
                            )

                            // Categories Filters Dropdown
                            var categoryExp by remember { mutableStateOf(false) }
                            Box {
                                FilterChip(
                                    selected = selectedCategoryFilter != null,
                                    onClick = { categoryExp = true },
                                    label = { Text(selectedCategoryFilter ?: "Category: All") },
                                    trailingIcon = { Icon(Icons.Default.ArrowDropDown, contentDescription = null) }
                                )
                                DropdownMenu(
                                    expanded = categoryExp,
                                    onDismissRequest = { categoryExp = false }
                                ) {
                                    DropdownMenuItem(
                                        text = { Text("Show All Categories") },
                                        onClick = {
                                            selectedCategoryFilter = null
                                            categoryExp = false
                                        }
                                    )
                                    availableCategories.forEach { cat ->
                                        DropdownMenuItem(
                                            text = { Text(cat) },
                                            onClick = {
                                                selectedCategoryFilter = cat
                                                categoryExp = false
                                            }
                                        )
                                    }
                                }
                            }

                            // Brand Filter Dropdown
                            var brandExp by remember { mutableStateOf(false) }
                            Box {
                                FilterChip(
                                    selected = selectedBrandFilter != null,
                                    onClick = { brandExp = true },
                                    label = { Text(selectedBrandFilter ?: "Brand: All") },
                                    trailingIcon = { Icon(Icons.Default.ArrowDropDown, contentDescription = null) }
                                )
                                DropdownMenu(
                                    expanded = brandExp,
                                    onDismissRequest = { brandExp = false }
                                ) {
                                    DropdownMenuItem(
                                        text = { Text("Show All Brands") },
                                        onClick = {
                                            selectedBrandFilter = null
                                            brandExp = false
                                        }
                                    )
                                    availableBrands.forEach { br ->
                                        DropdownMenuItem(
                                            text = { Text(br) },
                                            onClick = {
                                                selectedBrandFilter = br
                                                brandExp = false
                                            }
                                        )
                                    }
                                }
                            }

                            // Packaging Filter Dropdown
                            var packagingExp by remember { mutableStateOf(false) }
                            Box {
                                FilterChip(
                                    selected = selectedPackagingFilter != null,
                                    onClick = { packagingExp = true },
                                    label = { Text(selectedPackagingFilter ?: "Packaging: All") },
                                    trailingIcon = { Icon(Icons.Default.ArrowDropDown, contentDescription = null) }
                                )
                                DropdownMenu(
                                    expanded = packagingExp,
                                    onDismissRequest = { packagingExp = false }
                                ) {
                                    DropdownMenuItem(
                                        text = { Text("Show All Packaging") },
                                        onClick = {
                                            selectedPackagingFilter = null
                                            packagingExp = false
                                        }
                                    )
                                    availablePackaging.forEach { pack ->
                                        DropdownMenuItem(
                                            text = { Text(pack) },
                                            onClick = {
                                                selectedPackagingFilter = pack
                                                packagingExp = false
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }

                    if (filteredHistory.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center,
                                modifier = Modifier.padding(24.dp)
                            ) {
                                Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(64.dp), tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f))
                                Spacer(modifier = Modifier.height(16.dp))
                                Text("No Products Match Filters", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Text("Try clearing some active chips or modifying your keywords.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.outline, textAlign = TextAlign.Center)
                            }
                        }
                    } else {
                        LazyColumn(
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f)
                        ) {
                            items(
                                items = filteredHistory,
                                key = { it.id }
                            ) { item ->
                                val dismissState = rememberSwipeToDismissBoxState(
                                    confirmValueChange = { value ->
                                        if (value == SwipeToDismissBoxValue.EndToStart) {
                                            viewModel.deleteHistoryItem(item)
                                            Toast.makeText(context, "Item deleted", Toast.LENGTH_SHORT).show()
                                            true
                                        } else {
                                            false
                                        }
                                    }
                                )

                                SwipeToDismissBox(
                                    state = dismissState,
                                    backgroundContent = {
                                        val direction = dismissState.dismissDirection
                                        val color = when (direction) {
                                            SwipeToDismissBoxValue.EndToStart -> MaterialTheme.colorScheme.error
                                            else -> Color.Transparent
                                        }
                                        Box(
                                            modifier = Modifier
                                                .fillMaxSize()
                                                .clip(RoundedCornerShape(12.dp))
                                                .background(color)
                                                .padding(horizontal = 24.dp),
                                            contentAlignment = Alignment.CenterEnd
                                        ) {
                                            if (direction == SwipeToDismissBoxValue.EndToStart) {
                                                Icon(
                                                    imageVector = Icons.Default.Delete,
                                                    contentDescription = "Swipe Delete",
                                                    tint = Color.White
                                                )
                                            }
                                        }
                                    },
                                    enableDismissFromStartToEnd = false,
                                    content = {
                                        val isSelected = selectedItems.contains(item)
                                        HistoryItemCard(
                                            item = item,
                                            isSelected = isSelected,
                                            isMultiSelectActive = isMultiSelectActive,
                                            onClick = {
                                                if (isMultiSelectActive) {
                                                    if (isSelected) {
                                                        selectedItems.remove(item)
                                                        if (selectedItems.isEmpty()) {
                                                            isMultiSelectActive = false
                                                        }
                                                    } else {
                                                        selectedItems.add(item)
                                                    }
                                                } else {
                                                    viewModel.completeOnboarding()
                                                    viewModel.setCurrentScanResult(item)
                                                    onNavigateToTab(1) // Tab index 1 represents Tab 2 RESULTS
                                                    Toast.makeText(context, "Loaded into central workspace!", Toast.LENGTH_SHORT).show()
                                                }
                                            },
                                            onLongClick = {
                                                if (!isMultiSelectActive) {
                                                    isMultiSelectActive = true
                                                    selectedItems.add(item)
                                                }
                                            }
                                        )
                                    }
                                )
                            }
                            item {
                                Spacer(modifier = Modifier.height(90.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HistoryItemCard(
    item: OcrResultEntity,
    isSelected: Boolean,
    isMultiSelectActive: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit
) {
    val cardBorderColor = if (isSelected) {
        MaterialTheme.colorScheme.primary
    } else if (item.lowConfidenceFlag) {
        MaterialTheme.colorScheme.error.copy(alpha = 0.4f)
    } else {
        MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f)
    }

    val cardBgColor = if (isSelected) {
        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.15f)
    } else if (item.lowConfidenceFlag) {
        MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.05f)
    } else {
        MaterialTheme.colorScheme.surface
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                width = if (isSelected) 2.dp else 1.dp,
                color = cardBorderColor,
                shape = RoundedCornerShape(12.dp)
            )
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            ),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = cardBgColor)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (isMultiSelectActive) {
                Checkbox(
                    checked = isSelected,
                    onCheckedChange = { onClick() },
                    modifier = Modifier.size(24.dp)
                )
            }

            // Thumbnail
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.Black)
            ) {
                AsyncImage(
                    model = item.imageUri,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }

            // Info Details Column
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val format = remember { SimpleDateFormat("MM/dd/yyyy HH:mm", Locale.US) }
                    Text(
                        text = format.format(Date(item.timestamp)),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.outline
                    )

                    // Error Flag Warning vs Success standard
                    if (item.lowConfidenceFlag) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color(0xFFFF8F00).copy(alpha = 0.15f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "REVIEW REQ",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFFF8F00)
                            )
                        }
                    } else {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color(0xFF2E7D32).copy(alpha = 0.1f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "STANDARDIZED",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF2E7D32)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(2.dp))

                // Product Title
                Text(
                     text = item.itemName ?: "Unnamed Retail Product",
                     style = MaterialTheme.typography.titleMedium,
                     fontWeight = FontWeight.Black,
                     maxLines = 1,
                     overflow = TextOverflow.Ellipsis,
                     color = MaterialTheme.colorScheme.onSurface
                )

                Spacer(modifier = Modifier.height(2.dp))

                // Metadata Details: Brand, Barcode, etc.
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = item.brand ?: "Generic Brand",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "•",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.outline
                    )
                    Text(
                        text = item.barcode ?: "No Barcode",
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        color = MaterialTheme.colorScheme.outline
                    )
                    if (!item.weight.isNullOrBlank()) {
                        Text(
                            text = "•",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.outline
                        )
                        Text(
                            text = item.weight,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.secondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Sub-details category & Origin
                Text(
                    text = "Category: ${item.type ?: "-"} | Packaging: ${item.packagingType ?: "-"} | Origin: ${item.country ?: "-"}",
                    style = MaterialTheme.typography.bodySmall,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
fun EmptyHistoryView() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(110.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.05f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Info,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.4f),
                modifier = Modifier.size(48.dp)
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = "Pipeline Cache Empty",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "Any completed product scans with Auto-Save activated will automatically populate list cards here for quick review & multi-select file exports.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
    }
}

// SHARE & EXPORT SERIALIZER TO LOCAL FILESYSTEM SHARE INTENT
fun exportHistory(context: Context, historyList: List<OcrResultEntity>, asJson: Boolean) {
    try {
        val fileContent: String
        val fileName: String
        val mimeType: String

        if (asJson) {
            fileName = "maverick_imdb_export_${System.currentTimeMillis()}.json"
            mimeType = "application/json"
            val itemsJson = historyList.joinToString(separator = ",\n") { entity ->
                """
                {
                  "itemName": ${if (entity.itemName != null) "\"${entity.itemName.replace("\"", "\\\"")}\"" else "null"},
                  "barcode": ${if (entity.barcode != null) "\"${entity.barcode}\"" else "null"},
                  "manufacturer": ${if (entity.manufacturer != null) "\"${entity.manufacturer.replace("\"", "\\\"")}\"" else "null"},
                  "brand": ${if (entity.brand != null) "\"${entity.brand.replace("\"", "\\\"")}\"" else "null"},
                  "weight": ${if (entity.weight != null) "\"${entity.weight}\"" else "null"},
                  "packagingType": ${if (entity.packagingType != null) "\"${entity.packagingType}\"" else "null"},
                  "country": ${if (entity.country != null) "\"${entity.country}\"" else "null"},
                  "variant": ${if (entity.variant != null) "\"${entity.variant}\"" else "null"},
                  "type": ${if (entity.type != null) "\"${entity.type}\"" else "null"},
                  "fragranceFlavor": ${if (entity.fragranceFlavor != null) "\"${entity.fragranceFlavor}\"" else "null"},
                  "promotion": ${if (entity.promotion != null) "\"${entity.promotion.replace("\"", "\\\"")}\"" else "null"},
                  "addons": ${if (entity.addons != null) "\"${entity.addons}\"" else "null"},
                  "tagline": ${if (entity.tagline != null) "\"${entity.tagline.replace("\"", "\\\"")}\"" else "null"},
                  "rawText": "${(entity.rawText ?: "").replace("\"", "\\\"").replace("\n", "\\n")}",
                  "confidence": "${entity.confidence}",
                  "timestamp": ${entity.timestamp}
                }
                """.trimIndent()
            }
            fileContent = "[\n$itemsJson\n]"
        } else {
            fileName = "maverick_imdb_export_${System.currentTimeMillis()}.csv"
            mimeType = "text/csv"
            val header = "ITEM_NAME,BARCODE,MANUFACTURER,BRAND,WEIGHT,PACKAGING TYPE,COUNTRY,VARIANT,TYPE,FRAGRANCE_FLAVOR,PROMOTION,ADDONS,TAGLINE,OCRConfidence,Timestamp\n"
            
            val rows = historyList.joinToString(separator = "\n") { entity ->
                val cleanName = entity.itemName ?: ""
                val cleanBarcode = entity.barcode ?: ""
                val cleanMan = entity.manufacturer ?: ""
                val cleanBrand = entity.brand ?: ""
                val cleanWeight = entity.weight ?: ""
                val cleanPack = entity.packagingType ?: ""
                val cleanCountry = entity.country ?: ""
                val cleanVariant = entity.variant ?: ""
                val cleanType = entity.type ?: ""
                val cleanFrag = entity.fragranceFlavor ?: ""
                val cleanPromo = entity.promotion ?: ""
                val cleanAdd = entity.addons ?: ""
                val cleanTag = entity.tagline ?: ""
                
                fun escapeCsvField(field: String): String {
                    return if (field.contains(",") || field.contains("\n") || field.contains("\"")) {
                        "\"${field.replace("\"", "\"\"")}\""
                    } else {
                        field
                    }
                }
                
                "${escapeCsvField(cleanName)},${escapeCsvField(cleanBarcode)},${escapeCsvField(cleanMan)},${escapeCsvField(cleanBrand)},${escapeCsvField(cleanWeight)},${escapeCsvField(cleanPack)},${escapeCsvField(cleanCountry)},${escapeCsvField(cleanVariant)},${escapeCsvField(cleanType)},${escapeCsvField(cleanFrag)},${escapeCsvField(cleanPromo)},${escapeCsvField(cleanAdd)},${escapeCsvField(cleanTag)},${entity.confidence},${entity.timestamp}"
            }
            fileContent = header + rows
        }

        val outFile = File(context.cacheDir, fileName)
        outFile.writeText(fileContent)

        val shareUri = androidx.core.content.FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            outFile
        )

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType
            putExtra(Intent.EXTRA_STREAM, shareUri)
            putExtra(Intent.EXTRA_SUBJECT, "IMDB Master Product Export")
            putExtra(Intent.EXTRA_TEXT, "Exported IMDB Product Master rows.")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Share IMDB Export via"))
    } catch (e: Exception) {
        e.printStackTrace()
        Toast.makeText(context, "Export failed: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
    }
}
