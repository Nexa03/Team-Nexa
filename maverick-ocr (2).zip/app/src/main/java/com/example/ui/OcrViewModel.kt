package com.example.ui

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.OcrApplication
import com.example.data.local.OcrResultEntity
import com.example.data.repository.OcrRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class Achievement(
    val title: String,
    val description: String,
    val isUnlocked: Boolean,
    val badgeIconName: String, // visual identification
    val countProgress: Int,
    val countTarget: Int
)

class OcrViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: OcrRepository = (application as OcrApplication).repository
    private val prefs = application.getSharedPreferences("maverick_ocr_prefs", Context.MODE_PRIVATE)

    // UI States
    private val _onboardingCompleted = MutableStateFlow(prefs.getBoolean("onboarding_complete", false))
    val onboardingCompleted: StateFlow<Boolean> = _onboardingCompleted.asStateFlow()

    private val _isAnalyzing = MutableStateFlow(false)
    val isAnalyzing: StateFlow<Boolean> = _isAnalyzing.asStateFlow()

    private val _currentScanResult = MutableStateFlow<OcrResultEntity?>(null)
    val currentScanResult: StateFlow<OcrResultEntity?> = _currentScanResult.asStateFlow()

    private val _scannedUriToConfirm = MutableStateFlow<Uri?>(null)
    val scannedUriToConfirm: StateFlow<Uri?> = _scannedUriToConfirm.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    // Configuration states
    private val _autoSave = MutableStateFlow(prefs.getBoolean("settings_auto_save", true))
    val autoSave: StateFlow<Boolean> = _autoSave.asStateFlow()

    private val _preprocessing = MutableStateFlow(prefs.getBoolean("settings_preprocessing", true))
    val preprocessing: StateFlow<Boolean> = _preprocessing.asStateFlow()

    private val _confirmScan = MutableStateFlow(prefs.getBoolean("settings_confirm_scan", false))
    val confirmScan: StateFlow<Boolean> = _confirmScan.asStateFlow()

    // History Flow
    val allHistory: StateFlow<List<OcrResultEntity>> = repository.allResults.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Derived states (with automatic reactive calculation instead of manual triggers)
    val streakCount: StateFlow<Int> = allHistory.map { calculateStreak(it) }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = 0
    )

    val mergeSuggestions: StateFlow<List<OcrResultEntity>> = combine(
        _currentScanResult,
        allHistory
    ) { current, history ->
        if (current == null) return@combine emptyList()
        history.filter { item ->
            item.id != current.id && (
                (current.barcode != null && current.barcode.isNotBlank() && 
                 !current.barcode.startsWith("BAR-NEW-") && item.barcode == current.barcode) ||
                (current.brand != null && current.brand.isNotBlank() && current.brand != "Unknown Brand" &&
                 item.brand?.lowercase(Locale.US) == current.brand.lowercase(Locale.US) &&
                 hasVolumetricOverlap(current.weight, item.weight))
            )
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    private fun hasVolumetricOverlap(w1: String?, w2: String?): Boolean {
        if (w1.isNullOrBlank() || w2.isNullOrBlank()) return false
        val d1 = w1.filter { it.isDigit() }
        val d2 = w2.filter { it.isDigit() }
        return d1.isNotBlank() && d1 == d2
    }

    val achievements: StateFlow<List<Achievement>> = allHistory.map { history ->
        val count = history.size
        listOf(
            Achievement(
                title = "First Scan",
                description = "Scan your very first product label.",
                isUnlocked = count >= 1,
                badgeIconName = "lens",
                countProgress = count.coerceAtMost(1),
                countTarget = 1
            ),
            Achievement(
                title = "Text Detective",
                description = "Extract text from 10 or more labels.",
                isUnlocked = count >= 10,
                badgeIconName = "search",
                countProgress = count.coerceAtMost(10),
                countTarget = 10
            ),
            Achievement(
                title = "OCR Master",
                description = "Scan and extract 50 label images.",
                isUnlocked = count >= 50,
                badgeIconName = "psychology",
                countProgress = count.coerceAtMost(50),
                countTarget = 50
            ),
            Achievement(
                title = "100 Club",
                description = "Reach 100 scans to join our tech elite.",
                isUnlocked = count >= 100,
                badgeIconName = "workspace_premium",
                countProgress = count.coerceAtMost(100),
                countTarget = 100
            )
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    fun completeOnboarding() {
        prefs.edit().putBoolean("onboarding_complete", true).apply()
        _onboardingCompleted.value = true
    }

    fun resetOnboarding() {
        prefs.edit().putBoolean("onboarding_complete", false).apply()
        _onboardingCompleted.value = false
    }

    fun setAutoSave(enabled: Boolean) {
        prefs.edit().putBoolean("settings_auto_save", enabled).apply()
        _autoSave.value = enabled
    }

    fun setPreprocessing(enabled: Boolean) {
        prefs.edit().putBoolean("settings_preprocessing", enabled).apply()
        _preprocessing.value = enabled
    }

    fun setConfirmScan(enabled: Boolean) {
        prefs.edit().putBoolean("settings_confirm_scan", enabled).apply()
        _confirmScan.value = enabled
    }

    fun setupScanForProcessing(uri: Uri) {
        _errorMessage.value = null
        if (_confirmScan.value) {
            _scannedUriToConfirm.value = uri
        } else {
            // Process immediately
            triggerOcrPipelineImageUpload(uri)
        }
    }

    fun confirmProcessing() {
        _scannedUriToConfirm.value?.let { uri ->
            triggerOcrPipelineImageUpload(uri)
            _scannedUriToConfirm.value = null
        }
    }

    fun cancelProcessing() {
        _scannedUriToConfirm.value = null
    }

    fun clearResult() {
        _currentScanResult.value = null
        _errorMessage.value = null
    }

    fun triggerBarcodeLookup(barcode: String) {
        viewModelScope.launch {
            _isAnalyzing.value = true
            _errorMessage.value = null
            _currentScanResult.value = null
            try {
                val currentStreak = streakCount.value
                val result = repository.processBarcodeLookup(
                    barcode = barcode,
                    streakDayCount = currentStreak,
                    autoSave = _autoSave.value
                )
                _currentScanResult.value = result
            } catch (e: Exception) {
                _errorMessage.value = e.message ?: "Failed to lookup barcode. Point camera at barcode or edit manually."
            } finally {
                _isAnalyzing.value = false
            }
        }
    }

    fun triggerOcrPipelineImageUpload(uri: Uri) {
        viewModelScope.launch {
            _isAnalyzing.value = true
            _errorMessage.value = null
            _currentScanResult.value = null
            try {
                val currentStreak = streakCount.value
                val result = repository.processOcrPipelineImageUpload(
                    imageUri = uri,
                    streakDayCount = currentStreak,
                    autoSave = _autoSave.value
                )
                _currentScanResult.value = result
            } catch (e: Exception) {
                _errorMessage.value = e.message ?: "Failed to process image. Ensure text is clear."
            } finally {
                _isAnalyzing.value = false
            }
        }
    }

    fun triggerGeminiVisionFallback(uri: Uri, barcode: String?) {
        viewModelScope.launch {
            _isAnalyzing.value = true
            _errorMessage.value = null
            _currentScanResult.value = null
            try {
                val currentStreak = streakCount.value
                val result = repository.processGeminiVisionFallback(
                    imageUri = uri,
                    barcode = barcode,
                    streakDayCount = currentStreak,
                    autoSave = _autoSave.value
                )
                _currentScanResult.value = result
            } catch (e: Exception) {
                _errorMessage.value = e.message ?: "Failed to analyze image with Gemini."
            } finally {
                _isAnalyzing.value = false
            }
        }
    }

    fun saveScanResultDirect(entity: OcrResultEntity) {
        viewModelScope.launch {
            val id = repository.insertResultDirectly(entity)
            val updated = entity.copy(id = id.toInt())
            _currentScanResult.value = updated
        }
    }

    fun setCurrentScanResult(entity: OcrResultEntity?) {
        _currentScanResult.value = entity
    }

    private fun triggerOcrProcessing(uri: Uri) {
        viewModelScope.launch {
            _isAnalyzing.value = true
            _errorMessage.value = null
            _currentScanResult.value = null
            try {
                // Approximate streak value (computed first)
                val currentStreak = streakCount.value
                val result = repository.processNewScan(
                    imageUri = uri,
                    applyPreprocessing = _preprocessing.value,
                    autoSave = _autoSave.value,
                    streakDayCount = currentStreak
                )
                _currentScanResult.value = result
            } catch (e: Exception) {
                _errorMessage.value = e.message ?: "Failed to process image. Ensure text is clear."
            } finally {
                _isAnalyzing.value = false
            }
        }
    }

    fun deleteHistoryItem(entity: OcrResultEntity) {
        viewModelScope.launch {
            repository.deleteResult(entity)
        }
    }

    fun updateResult(entity: OcrResultEntity) {
        viewModelScope.launch {
            repository.updateResult(entity)
            if (_currentScanResult.value?.id == entity.id) {
                _currentScanResult.value = entity
            }
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            repository.clearAllHistory()
        }
    }

    fun deleteSelectedItems(items: List<OcrResultEntity>) {
        viewModelScope.launch {
            items.forEach { repository.deleteResult(it) }
        }
    }

    private fun calculateStreak(scans: List<OcrResultEntity>): Int {
        if (scans.isEmpty()) return 0
        val format = SimpleDateFormat("yyyyMMdd", Locale.US)
        val scanDates = scans.map { format.format(Date(it.timestamp)) }.toSet()

        val todayStr = format.format(Date())
        val calendar = Calendar.getInstance()

        calendar.add(Calendar.DAY_OF_YEAR, -1)
        val yesterdayStr = format.format(calendar.time)

        if (!scanDates.contains(todayStr) && !scanDates.contains(yesterdayStr)) {
            return 0
        }

        calendar.time = Date()
        var streak = 0
        while (true) {
            val dateStr = format.format(calendar.time)
            if (scanDates.contains(dateStr)) {
                streak++
                calendar.add(Calendar.DAY_OF_YEAR, -1)
            } else {
                break
            }
        }
        return streak
    }

    @Suppress("UNCHECKED_CAST")
    class Factory(private val application: Application) : ViewModelProvider.Factory {
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(OcrViewModel::class.java)) {
                return OcrViewModel(application) as T
            }
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}
