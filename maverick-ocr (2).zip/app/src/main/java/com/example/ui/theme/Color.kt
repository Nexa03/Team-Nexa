package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Color Palette
val IndigoPrimary = Color(0xFF3949AB)
val AmberSecondary = Color(0xFFFFA000)
val LightBg = Color(0xFFF3F0F5)
val LightSurface = Color(0xFFFFFFFF)

// Dark Color Palette
val PurpleDarkPrimary = Color(0xFFB39DDB)
val OrangeDarkSecondary = Color(0xFFFF8A65)
val DarkBg = Color(0xFF121216)
val DarkSurface = Color(0xFF1E1E24)
