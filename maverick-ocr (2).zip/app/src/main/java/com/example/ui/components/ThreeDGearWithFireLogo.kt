package com.example.ui.components

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.cos
import kotlin.math.sin

private fun floatSin(angleRad: Float): Float = sin(angleRad.toDouble()).toFloat()
private fun floatCos(angleRad: Float): Float = cos(angleRad.toDouble()).toFloat()

@Composable
fun ThreeDGearWithFireLogo(
    modifier: Modifier = Modifier,
    logoSize: Dp = 160.dp
) {
    val context = LocalContext.current
    var isOnline by remember { mutableStateOf(true) }

    // Monitor internet status
    DisposableEffect(context) {
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val networkCallback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                isOnline = true
            }
            override fun onLost(network: Network) {
                isOnline = false
            }
            override fun onUnavailable() {
                isOnline = false
            }
        }
        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()
        connectivityManager.registerNetworkCallback(request, networkCallback)

        val activeNetwork = connectivityManager.activeNetwork
        val capabilities = connectivityManager.getNetworkCapabilities(activeNetwork)
        isOnline = capabilities?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true

        onDispose {
            try {
                connectivityManager.unregisterNetworkCallback(networkCallback)
            } catch (e: Exception) {
                // Safe unregistration
            }
        }
    }

    // High performance animation loop using withFrameMillis to ensure smooth rotation
    // and bypassing any animator duration scaling limits.
    var rotationAngle by remember { mutableStateOf(0f) }
    var flameTime by remember { mutableStateOf(0f) }

    LaunchedEffect(Unit) {
        val startTime = withFrameMillis { it }
        while (true) {
            withFrameMillis { frameTime ->
                val elapsedMs = frameTime - startTime
                // 4000ms for a full 360 degree rotation
                rotationAngle = ((elapsedMs % 4000) / 4000f) * 360f
                // 1200ms for one complete cycle of wave oscillation (2 * PI)
                flameTime = ((elapsedMs % 1200) / 1200f) * 6.2831855f
            }
        }
    }

    // Reuse Path instances to prevent frame-by-frame GC allocations!
    val outerFirePath = remember { Path() }
    val midFirePath = remember { Path() }
    val innerFirePath = remember { Path() }
    val shadowPath = remember { Path() }
    val frontPath = remember { Path() }

    Box(
        modifier = modifier.size(logoSize),
        contentAlignment = Alignment.Center
    ) {
        // RADIAL BACKLIGHT GLOW
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val glowRadius = size.minDimension * 0.45f
            val glowColor = if (isOnline) {
                Color(0xFF0091EA).copy(alpha = 0.12f)
            } else {
                Color(0xFFFF6D00).copy(alpha = 0.12f)
            }
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(glowColor, Color.Transparent),
                    center = center,
                    radius = glowRadius
                ),
                radius = glowRadius,
                center = center
            )
        }

        // RENDERING THE GEAR AND FIRE
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val baseRadius = size.width * 0.28f

            val fireOuterColor = if (isOnline) Color(0xFF0D47A1) else Color(0xFFB71C1C)
            val fireMidColor = if (isOnline) Color(0xFF00B0FF) else Color(0xFFFF9100)
            val fireInnerColor = if (isOnline) Color(0xFFE0F7FA) else Color(0xFFFFFDE7)

            // 1a. Outer Fire Wave
            outerFirePath.reset()
            val numFlameSegments = 36
            val outerBaseR = baseRadius * 1.35f
            for (i in 0..numFlameSegments) {
                val fraction = i.toFloat() / numFlameSegments
                val angle = fraction * 6.2831855f
                val waveFactor1 = floatSin(angle * 8f + flameTime * 6f) * 6f
                val waveFactor2 = floatCos(angle * 13f - flameTime * 4f) * 4f
                val currentR = outerBaseR + waveFactor1 + waveFactor2

                val x = center.x + currentR * floatCos(angle)
                val y = center.y + currentR * floatSin(angle)
                if (i == 0) outerFirePath.moveTo(x, y) else outerFirePath.lineTo(x, y)
            }
            outerFirePath.close()

            drawPath(
                path = outerFirePath,
                color = fireOuterColor.copy(alpha = 0.45f),
                style = Stroke(width = 16f, cap = StrokeCap.Round, join = StrokeJoin.Round)
            )

            // 1b. Mid Fire Wave
            midFirePath.reset()
            val midBaseR = baseRadius * 1.2f
            for (i in 0..numFlameSegments) {
                val fraction = i.toFloat() / numFlameSegments
                val angle = fraction * 6.2831855f
                val waveFactor1 = floatSin(angle * 11f - flameTime * 8f) * 5f
                val waveFactor2 = floatCos(angle * 6f + flameTime * 5f) * 3f
                val currentR = midBaseR + waveFactor1 + waveFactor2

                val x = center.x + currentR * floatCos(angle)
                val y = center.y + currentR * floatSin(angle)
                if (i == 0) midFirePath.moveTo(x, y) else midFirePath.lineTo(x, y)
            }
            midFirePath.close()

            drawPath(
                path = midFirePath,
                color = fireMidColor.copy(alpha = 0.75f),
                style = Stroke(width = 10f, cap = StrokeCap.Round, join = StrokeJoin.Round)
            )

            // 1c. Inner Fire Wave
            innerFirePath.reset()
            val innerBaseR = baseRadius * 1.08f
            for (i in 0..numFlameSegments) {
                val fraction = i.toFloat() / numFlameSegments
                val angle = fraction * 6.2831855f
                val waveFactor = floatSin(angle * 15f + flameTime * 12f) * 4f
                val currentR = innerBaseR + waveFactor

                val x = center.x + currentR * floatCos(angle)
                val y = center.y + currentR * floatSin(angle)
                if (i == 0) innerFirePath.moveTo(x, y) else innerFirePath.lineTo(x, y)
            }
            innerFirePath.close()

            drawPath(
                path = innerFirePath,
                color = fireInnerColor,
                style = Stroke(width = 5f, cap = StrokeCap.Round, join = StrokeJoin.Round)
            )

            // 2. Rising Embers Field (Using simplified math for performance)
            val particleCount = 12
            for (i in 0 until particleCount) {
                val baseAngle = (i.toFloat() * (360f / particleCount)) * 0.017453292f
                val particlePhase = flameTime + (i.toFloat() * 1.7f)
                val driftR = baseRadius * 1.15f + (floatSin(particlePhase * 3f) * 14f)
                val driftAngle = baseAngle + (floatCos(particlePhase) * 0.12f)

                val px = center.x + driftR * floatCos(driftAngle)
                val py = center.y + driftR * floatSin(driftAngle)
                val pSize = 3f + (floatSin(particlePhase * 1.8f) + 1f) * 3f
                val pAlpha = 0.25f + (floatSin(particlePhase) + 1f) * 0.3f

                drawCircle(
                    color = fireMidColor.copy(alpha = pAlpha),
                    radius = pSize,
                    center = Offset(px, py)
                )
            }

            // 3. Rotating 3D Metallic Gear
            val numTeeth = 8
            val outerGearRadius = baseRadius
            val innerGearRadius = baseRadius * 0.76f
            val rotationRad = rotationAngle * 0.017453292f

            fun populateGearPath(path: Path, offset: Offset, outerRadius: Float, innerRadius: Float, rotation: Float) {
                path.reset()
                val angleStep = 6.2831855f / numTeeth
                val halfTooth = angleStep / 4f

                for (j in 0 until numTeeth) {
                    val toothAngle = j.toFloat() * angleStep + rotation

                    val a1 = toothAngle - halfTooth
                    val p1X = offset.x + innerRadius * floatCos(a1)
                    val p1Y = offset.y + innerRadius * floatSin(a1)

                    val a2 = toothAngle - halfTooth * 0.55f
                    val p2X = offset.x + outerRadius * floatCos(a2)
                    val p2Y = offset.y + outerRadius * floatSin(a2)

                    val a3 = toothAngle + halfTooth * 0.55f
                    val p3X = offset.x + outerRadius * floatCos(a3)
                    val p3Y = offset.y + outerRadius * floatSin(a3)

                    val a4 = toothAngle + halfTooth
                    val p4X = offset.x + innerRadius * floatCos(a4)
                    val p4Y = offset.y + innerRadius * floatSin(a4)

                    val a5 = toothAngle + angleStep - halfTooth
                    val p5X = offset.x + innerRadius * floatCos(a5)
                    val p5Y = offset.y + innerRadius * floatSin(a5)

                    if (j == 0) {
                        path.moveTo(p1X, p1Y)
                    } else {
                        path.lineTo(p1X, p1Y)
                    }
                    path.lineTo(p2X, p2Y)
                    path.lineTo(p3X, p3Y)
                    path.lineTo(p4X, p4Y)
                    path.lineTo(p5X, p5Y)
                }
                path.close()
            }

            // A. Shadow Extrusion Output
            val shadowOffset = Offset(center.x + 6f, center.y + 10f)
            populateGearPath(shadowPath, shadowOffset, outerGearRadius, innerGearRadius, rotationRad)
            drawPath(
                path = shadowPath,
                color = Color(0xFF101014)
            )

            // B. Front Face Titanium gradient
            populateGearPath(frontPath, center, outerGearRadius, innerGearRadius, rotationRad)
            val chromeMetallicBrush = Brush.linearGradient(
                colors = listOf(
                    Color(0xFFE2E2E6),
                    Color(0xFF8E929E),
                    Color(0xFF4C505C)
                ),
                start = Offset(center.x - baseRadius, center.y - baseRadius),
                end = Offset(center.x + baseRadius, center.y + baseRadius)
            )
            drawPath(
                path = frontPath,
                brush = chromeMetallicBrush
            )

            // C. Shiny highlight rim
            val rimHighlightColor = if (isOnline) Color(0xFFB3E5FC) else Color(0xFFFFCC80)
            drawPath(
                path = frontPath,
                color = rimHighlightColor.copy(alpha = 0.5f),
                style = Stroke(width = 3f)
            )

            // D. Axle Plate cap
            val centralCapRadius = baseRadius * 0.52f
            val rivetsCircleRadius = centralCapRadius * 0.72f

            val steelHubBrush = Brush.radialGradient(
                colors = listOf(Color(0xFFFAFAFA), Color(0xFF757575), Color(0xFF212121)),
                center = center,
                radius = centralCapRadius
            )
            drawCircle(
                brush = steelHubBrush,
                radius = centralCapRadius,
                center = center
            )

            drawCircle(
                color = Color.White.copy(alpha = 0.4f),
                radius = centralCapRadius,
                center = center,
                style = Stroke(width = 2.5f)
            )

            drawCircle(
                color = Color(0xFF0C0C0E),
                radius = centralCapRadius * 0.28f,
                center = center
            )

            // E. Assembly Rivets
            val rivetCount = 6
            val rivetSize = 3.5f
            for (k in 0 until rivetCount) {
                val rivetAngle = k.toFloat() * (360f / rivetCount) * 0.017453292f + (rotationRad * 0.4f)
                val rx = center.x + rivetsCircleRadius * floatCos(rivetAngle)
                val ry = center.y + rivetsCircleRadius * floatSin(rivetAngle)

                drawCircle(
                    color = Color(0xFFEEEEEE),
                    radius = rivetSize,
                    center = Offset(rx, ry)
                )
                drawCircle(
                    color = Color.Black.copy(alpha = 0.5f),
                    radius = rivetSize,
                    center = Offset(rx, ry),
                    style = Stroke(width = 1f)
                )
            }
        }
    }
}
